package com.l000phone.spark_core.day05.demo03_partition.sample02_complexpartition

import java.net.URL

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
  * Description：根据用访问数据进行统计，用户对各个学科的各个模块的访问量Top3, 要求：将最终的结果保存到文件中，且将不同学科最受欢迎的前3个模块信息保存到相应的文件中<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月27日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SubjectDemo {
  def main(args: Array[String]): Unit = {
    //步骤：

    //前提：
    //println(s"域名信息是：${getDomainName("http://h5.learn.com/h5/teacher.shtml")}");

    //①SparkSession
    val spark: SparkSession = SparkSession.builder.
      appName(SubjectDemo.getClass.getSimpleName).
      master("local[*]").
      getOrCreate

    //②分析RDD,20201123101523	http://java.learn.com/java/javaee.shtml
    calaSubjectTop3Module(spark)

    //③释放资源
    spark.stop
  }

  /**
    *
    * 计算各个学科方向最受欢迎的前3个module
    *
    * @param spark
    */
  private def calaSubjectTop3Module(spark: SparkSession) = {
    val rdd: RDD[(String, (String, Int))] = spark.sparkContext.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\subject")
      .map(perEle => {
        val arr = perEle.split("\\s+")
        val url = arr(1).trim
        (url, 1)
      }).reduceByKey(_ + _)
      .map(perEle => {
        val url = perEle._1
        val subjectName = getDomainName(url)
        val moduleName = url.substring(url.lastIndexOf('/') + 1, url.lastIndexOf('.'))
        (subjectName, (moduleName, perEle._2))
      })

    //构建MyComplexPartitioner的实例
    val myPartitioner = new MyComplexPartitioner(rdd.keys.distinct.collect)

    //设置自定义分区
    rdd.partitionBy(myPartitioner)
      .mapPartitions((itr: Iterator[(String, (String, Int))]) => {
        //每个分区中的元素直接求top3,因为当前分区中存储的就是当前主题所有的模块访问信息
        itr.toList.sortBy(_._2._2).reverse.take(3).iterator
      }).saveAsTextFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\subject\\out")

  }

  /**
    * 根据url获得域名信息
    *
    * @param url
    * @return
    */
  def getDomainName(url: String) = {
    new URL(url).getHost
  }
}
