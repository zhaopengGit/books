package com.l000phone.spark_core.day03.demo03_sharevar

import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

/**
  * Description：共享变量之广播变量演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月26日
  *
  * @author 徐文波
  * @version : 1.0
  */
object BroadcastVarDemo extends App {
  //①SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(BroadcastVarDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  val sc: SparkContext = spark.sparkContext

  //②验证广播变量
  val age: Int = 1

  val rdd = sc.parallelize(Seq(12, 15, 10, 16), 2)
  rdd.map(perEle => {
    var tmp = perEle + age
    tmp
  })
  rdd.foreach(println)

  println("\n___________________________________________\n")

  val intBrod: Broadcast[Int] = sc.broadcast[Int](age)//将实例封装为广播变量,封装到Broadcast实例中的实例必须是可序列化的，如何实现？该实例所对应的类要实现java.io.Serializable
  val rdd2= sc.parallelize(Seq(12, 15, 10, 16), 2)
  rdd2.map(perEle => {
    var tmp = perEle + intBrod.value
    tmp
  })
  rdd2.foreach(println)



  //③资源释放
  spark.stop
}
