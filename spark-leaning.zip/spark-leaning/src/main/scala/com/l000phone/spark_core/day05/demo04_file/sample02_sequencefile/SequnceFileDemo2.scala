package com.l000phone.spark_core.day05.demo04_file.sample02_sequencefile

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializerFeature
import com.l000phone.entity.Student
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
  * Description：sequnce文件读取，以json格式写出<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SequnceFileDemo2 {
  def main(args: Array[String]): Unit = {
    //①SparkSession
    val spark: SparkSession = SparkSession.builder.
      appName(SequnceFileDemo2.getClass.getSimpleName).
      master("local[*]").
      getOrCreate

    //②读取json格式的数据为rdd
    val rdd: RDD[(Int, String)] = spark.sparkContext.sequenceFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sequence")

    val resultRDD:RDD[String] = rdd.map(perEle=>{
      val id = perEle._1
      val arr = perEle._2.split("-")
      val name = "→" + arr(0).trim +"←"
      val address = arr(1).trim
      JSON.toJSONString(new Student(id,name,address), SerializerFeature.UseSingleQuotes)
    })

    resultRDD.saveAsTextFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\json\\out2")
    //③释放资源
    spark.stop
  }
}
