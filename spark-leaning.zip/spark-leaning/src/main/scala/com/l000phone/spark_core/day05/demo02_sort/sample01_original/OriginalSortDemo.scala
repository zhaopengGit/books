package com.l000phone.spark_core.day05.demo02_sort.sample01_original

import org.apache.spark.sql.SparkSession

/**
  * Description：使用官方API中类型（已经定制好了排序规则）<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
object OriginalSortDemo {
  def main(args: Array[String]): Unit = {
    //①SparkSession
    val spark: SparkSession = SparkSession.builder().
      appName(OriginalSortDemo.getClass.getSimpleName).
      master("local[*]").getOrCreate()

    //②RDD,排序，根据Girl的颜值降序排列
    spark.sparkContext.parallelize(Seq(
      ("Jone", 86, 18, 164.34),
      ("Kate", 90, 30, 178.34),
      ("Marry", 90, 29, 168.34),
      ("leon", 86, 18, 160.34)), 1)
      .sortBy(_._2, false)
      .foreach(println)

    //③释放资源
    spark.stop

  }
}
