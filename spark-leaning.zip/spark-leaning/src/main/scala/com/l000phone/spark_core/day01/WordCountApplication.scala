package com.l000phone.spark_core.day01

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Description：Scala版本入门级的案例之WordCount<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月24日
  *
  * @author 徐文波
  * @version : 1.0
  */
object WordCountApplication {

  def main(args: Array[String]): Unit = {
    //步骤：
    //前提:
    //拦截非法的参数
    if (args == null || args.length != 2) {
      println(s"请传入参数！参数1→待计算的源；参数2→目的地")
      System.exit(1);
    }

    val inputPath = args(0).trim
    val outputPath = args(1).trim


    //①构建SparkConf的实例
    val conf: SparkConf = new SparkConf
    //通过参数传递进来
    //conf.setMaster("local[*]")
    conf.setAppName(WordCountApplication.getClass.getSimpleName)


    //②构建SparkContext的实例 （SparkSession的实例）
    val sc: SparkContext = new SparkContext(conf)

    //③分步骤求WordCount
    //a)加载指定的文件为RDD (RDD:弹性分布式数据集，可以理解为集合，该集合中存储的元素跨越了多个虚拟机的内存，就是worker守护进行启动着的Executor进程对应的内存区域中)
    val lineRDD: RDD[String] = sc.textFile(inputPath)

    //b) 将文件中每行内容转换成数组并压平，置于一个全新的RDD中
    val wordRDD: RDD[String] = lineRDD.flatMap(_.split("\\s+")).filter(_.trim != "")

    //c)将RDD中每个元素转换成元组
    val tupleRDD: RDD[(String, Int)] = wordRDD.map((_, 1))

    //d)计算单词出现的次数
    val reduceRDD: RDD[(String, Int)] = tupleRDD.reduceByKey(_ + _)

    //e)处理结果（i→排序，打印输出；ii→排序，存储起来）
    val sortAfterRDD: RDD[(String, Int)] = reduceRDD.sortBy(_._2, false, 1)

    //sortAfterRDD.collect.foreach(println)
    sortAfterRDD.saveAsTextFile(outputPath)

    //④资源释放
    sc.stop
  }

}
