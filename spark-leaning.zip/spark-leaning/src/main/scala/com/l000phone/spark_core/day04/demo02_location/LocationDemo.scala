package com.l000phone.spark_core.day04.demo02_location

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
  * Description： 基站停留时间TopN<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月27日
  *
  * @author 徐文波
  * @version : 1.0
  */
object LocationDemo {


  def main(args: Array[String]): Unit = {
    //0)前提： SparkSession
    val spark: SparkSession = SparkSession.builder.
      appName(LocationDemo.getClass.getSimpleName).
      master("local[*]").
      getOrCreate()

    val sc: SparkContext = spark.sparkContext

    //1）读取用户产生的记录信息的日志文件 （就是：进入某个基站范围，在基站后台留下的日志信息）
    val accessRDD: RDD[(String, (String, Long))] = generateAccessRDD(sc)

    //２）读取基站的信息文件
    val baseRDD: RDD[(String, (String, String))] = generateBaseRDD(sc)

    //3） 将上述步骤中的rdd进行内连接查询
    rddJoinOperation(accessRDD, baseRDD)

    //4）资源释放
    spark.stop
  }


  /**
    * rdd进行内连接查询
    *
    * @param accessRDD
    * @param baseRDD
    */
  def rddJoinOperation(accessRDD: RDD[(String, (String, Long))], baseRDD: RDD[(String, (String, String))]) = {
    accessRDD.join(baseRDD)
      .map(perEle => {
        val stationId = perEle._1
        val phoneNumAndStayTime = perEle._2._1
        val phoneNum = phoneNumAndStayTime._1
        val stayTime = phoneNumAndStayTime._2
        // (phoneNum, stationId, stayTime, perEle._2._2)
        (phoneNum, perEle._2._2)
      }).foreach(println)
  }


  /**
    * 取用户产生的记录信息的日志文件 （就是：进入某个基站范围，在基站后台留下的日志信息）,转换成RDD
    *
    * @param sc
    */
  def generateAccessRDD(sc: SparkContext) = {
    //　　file→ 封装成rdd → key: 电话号码+基站id   value: 时间戳 （if （标志值==1） -时间戳 else 时间戳）
    sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\location\\log")
      .map(perLine => {
        var arr = perLine.split(",")
        val phoneNum = arr(0).trim
        val time = arr(1).trim.toLong
        val stationId = arr(2).trim
        val flg = arr(3).trim // 1连接 0断开
        val willCalTime = if (flg == 1) -time else time
        (phoneNum + "_" + stationId, willCalTime)
      })

      //→ reduceByKey ，每个元素中的值是：（电话号码+基站id，停留的时长）
      .reduceByKey(_ + _)

      //→ 对rdd中的元素变形，将每个元素变形为：（手机号码，（基站id,停留时长））
      .map(perEle => {
      val arr = perEle._1.split("_")
      val phoneNum = arr(0).trim
      val stationId = arr(1).trim
      (phoneNum, (stationId, (phoneNum, perEle._2)))
    })

      //→groupBy(电话号码，集合（（基站id1,时长1），（基站id2,时长2），。。。）)
      .groupByKey()

      //→求top2→RDD元素变形，key:基站id，value：xxx
      .mapValues(_.toList.sortWith(_._2._2 > _._2._2).take(2))
      .flatMap(perEle => perEle._2)
  }


  /**
    * 读取基站的信息文件,分析RDD
    *
    * @param sc
    */
  def generateBaseRDD(sc: SparkContext) = {
    //file →封装成rdd  → RDD元素变形，key:基站id，value：xxx
    sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\location\\lac_info.txt")
      .map(perLine => {
        val arr = perLine.split(",")
        val stationId = arr(0).trim
        val jindu = arr(1).trim
        val weidu = arr(2).trim
        (stationId, (jindu, weidu))
      })
  }
}
