package com.l000phone.spark_core.day05.demo03_partition.sample01_simpleselfpartition

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
  * Description： 简单自定义分区演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SimpleSelfPartitionerDemo {
  def main(args: Array[String]): Unit = {
    //①SparkSession
    val spark: SparkSession = SparkSession.builder().
      appName(SimpleSelfPartitionerDemo.getClass.getSimpleName).
      master("local[*]").getOrCreate()

    val sc: SparkContext = spark.sparkContext

    //②分区演示
    //a)使用默认的分区
    val rdd: RDD[(Int, Long)] = sc.parallelize(1 to 10, 1).zipWithIndex()

    rdd.mapPartitionsWithIndex(fun).foreach(println)

    println("\n___________________________________________________________\n")

    //b)使用自定义分区
    val rdd2 = rdd.partitionBy(new MyPartitioner(3))
    rdd2.mapPartitionsWithIndex(fun).foreach(println)

    //③释放资源
    spark.stop

  }


  //赋值式的有名函数
  val fun = (index: Int, itr: Iterator[(Int, Long)]) => {
    itr.map(perEle => s"分区编号：$index,元素值：$perEle")
  }
}
