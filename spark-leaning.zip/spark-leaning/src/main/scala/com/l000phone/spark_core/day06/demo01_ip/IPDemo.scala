package com.l000phone.spark_core.day06.demo01_ip

import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Description：根据http.log日志文件以及ip.txt ip地址信息文件，要求统计计算出不同省份当天的访问量。<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月01日
  *
  * @author 徐文波
  * @version : 1.0
  */
object IPDemo {
  def main(args: Array[String]): Unit = {


    //步骤：
    //前提：
    //0： SparkSession
    val spark: SparkSession = SparkSession
      .builder
      .master("local[*]")
      .appName(IPDemo.getClass.getSimpleName)
      .getOrCreate

    val sc: SparkContext = spark.sparkContext


    //①将ip.txt文件读取到内存中，将其封装到广播变量中存储起来，Array(province, 开始的ip对应的数值型，结束的ip对应的数值型 )
    //a) ip.txt → RDD[(String,Long,Long)] → Array[(String,Long,Long)]]
    val arr: Array[(String, String, String)] = sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\ip\\ip.txt")
      .map(_.split("\\|"))
      .map(arr => {
        val province = arr(6).trim()
        val startIp = arr(2).trim
        val endIp = arr(3).trim
        (province, startIp, endIp)
      }).collect()

    //b) Array[(String,Long,Long)]] → BoardCast(Array)
    val ipBroad: Broadcast[Array[(String, String, String)]] = sc.broadcast(arr)

    //②将日志文件读取到内存中，将RDD中的每个元素最终变形为：（ip地址，1），借助于广播变量中存储的ip地址的信息，从容器中查询到ip地址对应的省份信息，
    //			 将RDD中的每个元素最终变形为：（省份名，1） -> reduceByKey ....
    sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\ip\\http.log")
      .map(_.split("\\|"))
      .map(arr => {
        //a)获取ip地址
        val ip = arr(1).trim
        //b)转换为long类型
        val ipLong = ip2Long(ip)
        //c)从广播变量中封装的Array中取查找到当前的ip对应的索引值
        var ipArr: Array[(String, String, String)] = ipBroad.value
        val index = binarySearch(ipArr, ipLong)

        //d)根据索引值直接获取Array中的元素，得到了省份信息
        val provinceName = ipArr(index)._1

        //e)返回，将RDD中每个元素变形为：（省份名，1）
        (provinceName, 1)
      }).reduceByKey(_ + _)
      .foreach(println)


    //释放资源
    spark.stop
  }


  /**
    * 将ip地址转换为long类型
    *
    * @param ip
    * @return
    */
  def ip2Long(ip: String): Long = {
    val fragments = ip.split("[.]")
    var ipNum = 0L
    for (i <- 0 until fragments.length) {
      ipNum = fragments(i).toLong | ipNum << 8L
    }
    ipNum
  }

  /**
    * 二分法查找,查找到的是ip地址在容器中的索引值
    *
    * @param arr
    * @param ip
    * @return
    */
  def binarySearch(arr: Array[(String, String, String)], ip: Long): Int = {
    var low = 0
    var high = arr.length
    while (low <= high) {
      val middle = (low + high) / 2
      if ((ip >= arr(middle)._2.toLong) && (ip <= arr(middle)._3.toLong)) {
        return middle
      }
      //修改右边界
      if (ip < arr(middle)._2.toLong) {
        high = middle - 1
      }
      //修改左边界
      if(ip> arr(middle)._3.toLong)
      {
        low = middle + 1
      }
    }
    -1
  }
}
