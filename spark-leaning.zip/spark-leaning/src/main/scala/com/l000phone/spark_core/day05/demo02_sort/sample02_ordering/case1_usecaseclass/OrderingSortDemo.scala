package com.l000phone.spark_core.day05.demo02_sort.sample02_ordering.case1_usecaseclass

import org.apache.spark.sql.SparkSession

/**
  * Description： 自定义排序规则之Ordering方式<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
object OrderingSortDemo {
  def main(args: Array[String]): Unit = {
    //①SparkSession
    val spark: SparkSession = SparkSession.builder().
      appName(OrderingSortDemo.getClass.getSimpleName).
      master("local[*]").getOrCreate()

    //导入隐式实例
    import MyPredef.girl

    //②RDD,排序，根据Girl的颜值降序排列
    spark.sparkContext.parallelize(Seq(
      ("Jone", 86, 18, 164.34),
      ("Kate", 90, 30, 178.34),
      ("Marry", 90, 29, 168.34),
      ("leon", 86, 18, 160.34)), 1)
      .sortBy(perEle => new Girl(perEle._1, perEle._2, perEle._3, perEle._4))
      .foreach(println)

    //③释放资源
    spark.stop

  }
}
