package com.l000phone.spark_core.day05.demo03_partition.sample02_complexpartition

import org.apache.spark.Partitioner

import scala.collection.mutable

/**
  * Description：学科自定义分区<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
class MyComplexPartitioner(subjects: Seq[String]) extends Partitioner {

  //准备一个容器，存储学科以及该学科对应的分区编号
  val container: mutable.Map[String, Int] = mutable.Map[String, Int]()

  //填充容器，从参数subjects: Seq[String]中取出元素进行填充，分区编号就是学科在集合中的索引值
  var index = 0
  for (ele <- subjects) {
    container.put(ele, index)
    index += 1
  }


  /**
    * 分区数
    *
    * @return
    */
  override def numPartitions: Int = subjects.size

  /**
    * 获得参数指定的key所对应的分区
    *
    * @param key
    * @return
    */
  override def getPartition(key: Any): Int = container.getOrElse(key.toString, 0)
}
