package com.l000phone.spark_core.day03.demo03_sharevar


import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.util.LongAccumulator

/**
  * Description：共享变量之累加器演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月26日
  *
  * @author 徐文波
  * @version : 1.0
  */
object AccumulaterDemo {
  def main(args: Array[String]): Unit = {
    //①SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(BroadcastVarDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //②验证共享变量之累加器
    //a)准备一个累加器的实例
    val myacc = new LongAccumulator()

    //b)注册累加器
    sc.register(myacc, "myacc")

    //c)在rdd中算子中使用累加器
    val rdd: RDD[Int] = sc.parallelize(Seq(1, 2, 3, 4, 5, 6))

    //统计rdd中元素的个数
    val rdd2 = rdd.map(perEle => {
      myacc.add(1)
      //println(s"→ 读取累加器的值，结果是：${myacc.value}")
    })

    rdd2.count

    //注意：在Driver进程中读取累加器的值
    println(s"读取累加器的值，结果是：${myacc.value}")

    //③资源释放
    spark.stop
  }
}
