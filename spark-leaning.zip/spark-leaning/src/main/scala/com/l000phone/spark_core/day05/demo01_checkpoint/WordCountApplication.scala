package com.l000phone.spark_core.day05.demo01_checkpoint

import java.io._

import com.l000phone.util.FileUtil
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Description：Scala版本入门级的案例之WordCount，checkpoint探讨<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  *
  * @author 徐文波
  * @version : 1.0
  */
object WordCountApplication {

  def main(args: Array[String]): Unit = {
    //步骤：
    //前提:
    //拦截非法的参数

    val inputPath = "file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\wc\\hello.txt"
    val outputPath = "file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\out"

    val ckDir = "file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\ck"

    //①构建SparkConf的实例
    val conf: SparkConf = new SparkConf
    //通过参数传递进来j
    conf.setMaster("local[*]")
    conf.setAppName(WordCountApplication.getClass.getSimpleName)


    //②构建SparkContext的实例 （SparkSession的实例）
    val sc: SparkContext = new SparkContext(conf)


    //③分步骤求WordCount
    //a)加载指定的文件为RDD (RDD:弹性分布式数据集，可以理解为集合，该集合中存储的元素跨越了多个虚拟机的内存，就是worker守护进行启动着的Executor进程对应的内存区域中)
    var lineRDD: RDD[String] = null

    var file: File = new File("C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\recorder\\dir.txt")

    val reader: BufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))
    var content = reader.readLine()
    try {
      if (content != null && !"".equals(content.trim)) {
        val src = content.substring(0, content.lastIndexOf('/'))
        var target = content + "_bak"

        FileUtil.moveFolder(src, target)

        sc.setCheckpointDir(content)

        FileUtil.moveFolder(target, src)
      }
      else {
        sc.setCheckpointDir(ckDir)
        var dir = sc.getCheckpointDir.get

        val out: PrintWriter = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"))
        out.println(dir + "/*")
        out.flush()
      }

      lineRDD = sc.textFile(inputPath)

      lineRDD.checkpoint


      lineRDD.count

    } catch {
      case _ => {

        lineRDD = sc.textFile(content)
      }

    }


    //lineRDD.checkpoint

    //lineRDD.count

    //b) 将文件中每行内容转换成数组并压平，置于一个全新的RDD中
    val wordRDD: RDD[String] = lineRDD.flatMap(_.split("\\s+")).filter(_.trim != "")

    //c)将RDD中每个元素转换成元组
    val tupleRDD: RDD[(String, Int)] = wordRDD.map((_, 1))

    //d)计算单词出现的次数
    val reduceRDD: RDD[(String, Int)] = tupleRDD.reduceByKey(_ + _)

    //e)处理结果（i→排序，打印输出；ii→排序，存储起来）
    val sortAfterRDD: RDD[(String, Int)] = reduceRDD.sortBy(_._2, false, 1)

    //sortAfterRDD.collect.foreach(println)

    val outputPathFile = new File(outputPath.replace("file:/", ""))
    if (outputPathFile.exists()) {
      FileUtil.delDir(outputPathFile)
    }

    sortAfterRDD.saveAsTextFile(outputPath)

    //④资源释放
    sc.stop
  }

}
