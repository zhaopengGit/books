package com.l000phone.spark_core.day05.demo02_sort.sample02_ordering.case2_usecommonclass

/**
  * Description：Girl样例类<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
class Girl(var name: String, var faceValue: Int, var age: Int, var height: Double) extends Serializable
