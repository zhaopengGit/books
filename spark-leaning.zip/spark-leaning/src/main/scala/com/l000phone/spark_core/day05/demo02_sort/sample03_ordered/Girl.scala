package com.l000phone.spark_core.day05.demo02_sort.sample03_ordered

/**
  * Description：Girl样例类<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
case class Girl2(name: String, faceValue: Int, age: Int, height: Double) extends Ordered[Girl2] {
  /**
    * 定制比较规则
    *
    * 经验：
    * 经验的总结：
    * 升序： 计算时this参数置于前
    * 降序： 计算时that参数置于前
    *
    * @param that
    * @return
    */
  override def compare(that: Girl2): Int = {
    //判断颜值，颜值相同，判断年龄，年龄相同，再比较身高
    val faceComp = that.faceValue - this.faceValue
    if (faceComp == 0) {
      val ageComp = this.age - that.age
      if (ageComp == 0) {
        return (that.height - this.height).toInt
      }
      return ageComp
    }
    return faceComp
  }
}
