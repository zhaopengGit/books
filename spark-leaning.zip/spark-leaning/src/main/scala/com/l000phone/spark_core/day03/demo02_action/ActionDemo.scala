package com.l000phone.spark_core.day03.demo02_action

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.joda.time.DateTime

import scala.collection.mutable.ListBuffer

/**
  * Description：常用的Action算子演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月26日
  *
  * @author 徐文波
  * @version : 1.0
  */
object ActionDemo {


  def main(args: Array[String]): Unit = {
    //①SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(ActionDemo.getClass.getSimpleName)
      .master("local[3]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext


    //②算子演示
    //a) aggregate(zeroValue)(seqOp, combOp, [numTasks])   : 科里化的第一个参数列表→ 初始值; 科里化的第二个参数列表的第一参数作用于每个分区；科里化的第二个参数列表的第二参数作用于全局
    //aggregateDo(sc)

    //b)reduce, collect,count,first,top,take,takeOrdered
    //val rdd:RDD[Int] = sc.parallelize(Seq(6,1, 2, 3, 4, 5,  7, 8))
    //println(s"reduce之后的结果是：${rdd.reduce(_ + _)}")
    //println(s"collect之后的结果是：${rdd.collect.toBuffer}")
    //println(s"first，rdd中第一个元素是：${rdd.first}")
    //println(s"top，rdd中降序排列后的前3个元素是：${rdd.top(3).toBuffer}")
    //println(s"take，取出rdd中前3个元素是：${rdd.take(3).toBuffer}")
    //println(s"takeOrdered，取出rdd中前3个且排好序的元素是：${rdd.takeOrdered(3).toBuffer}")

    //c)countByKey 针对(K,V)类型的RDD，返回一个(K,Int)的map，表示每一个key对应的元素个数。
    val rdd: RDD[(String, Int)] = sc.parallelize(List(("key1", 3), ("key1", 3), ("key3", 3), ("key3", 6), ("key5", 5)))
    rdd.countByKey().foreach(println)

    println("\n_________________________________________________\n")

    //d) countByValue 也是要求RDD中每个元素是对偶元组，返回值是Map[T, Long]，T~> 原来RDD中的元组；Long:出现的次数
    rdd.countByValue().foreach(println)


    //e)saveAsSequenceFile ,将rdd序列化输出到指定的目录下
   // rdd.saveAsSequenceFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\output3")
    rdd.saveAsObjectFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\output4")

    println("\n_________________________________________________\n")

    //f) collectAsMap , 将源rdd中每个元素（对偶元组）取出来，置于Map容器中,注意：根据map集合中的key去重
    sc.parallelize(List(("key1", 3), ("key1", 3), ("key3", 3), ("key3", 6), ("key5", 5))).collectAsMap().foreach(println)

    //③资源释放
    spark.stop

  }


  def getHour(timelong: String): String = {
    val datetime = new DateTime(timelong.toLong)
    datetime.getHourOfDay.toString
  }

  /**
    * Action算子之aggregate
    *
    * @param sc
    */
  def aggregateDo(sc: SparkContext) = {
    val rdd: RDD[Int] = sc.parallelize(Seq(1, 2, 3, 4, 5, 6, 7, 8), 2)

    //需求：将每个分区中的最大值累加起来
    showDetailInfo(rdd)

    // (5,1)
    // (1,0)
    // (6,1)
    // (2,0)
    // (7,1)
    // (3,0)
    // (8,1)
    // (4,0)
    //→ 0号分区中的最大值是：4；1号分区中的最大值是：8 。然后，初始值根据局部比较的规则也参与比较。在全局比较时，初始值也参与运算。
    //  4
    //  8

    // 3 - 4 - 8 = -9

    //---------
    //  5
    //  8
    // 5 - 5 - 8 = -8


    val finalResult: Int = rdd.aggregate(5)(math.max(_, _), _ * _)
    println(finalResult)
  }


  /**
    * 查看RDD的详情
    *
    * @param rdd
    */
  def showDetailInfo(rdd: RDD[Int]) = {
    rdd.mapPartitionsWithIndex((index, itr) => {

      val container: ListBuffer[(Int, Int)] = new ListBuffer()
      itr.foreach(perEle => container.append((perEle, index)))

      container.toList.toIterator
    }).foreach(println)
  }

}
