package com.l000phone.spark_core.day03.demo04

import com.l000phone.spark_core.day03.demo03_sharevar.BroadcastVarDemo
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ListBuffer

/**
  * Description：需求：统计每一个省份点击TOP3的广告ID<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月26日
  *
  * @author 徐文波
  * @version : 1.0
  */
object PerProvinceClickTop3Ad {

  def main(args: Array[String]): Unit = {
    //思路：
    //①SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(BroadcastVarDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //②计算
    //i)基于源构建RDD
    val rdd: RDD[String] = sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\ad\\ad.txt")

    //ii)分析RDD
    val arrRDD: RDD[Array[String]] = rdd.map(_.split("\\s+"))

    val tupleRDD: RDD[(String, Int)] = arrRDD.map(arr => {
      val province = arr(1).trim
      val adId = arr(4).trim

      (province + "_" + adId, 1)
    })

    val sumRDD: RDD[(String, Int)] = tupleRDD.reduceByKey(_ + _)


    //根据省份分组求topN
    val changeAfterRDD: RDD[(String, String, Int)] = sumRDD.map(perEle => {
      val arr = perEle._1.split("_")
      val province = arr(0).trim
      val adId = arr(1).trim
      (province, adId, perEle._2)
    })

    //根据省份来分组
    //changeAfterRDD.groupBy(_._1).mapValues(_.toList.sortBy(_._3).reverse.take(3)).foreach(println)
    //val tempRDD =  changeAfterRDD.groupBy(_._1).mapValues(_.toList.sortWith(_._3 > _._3))
    // showDetailInfo(tempRDD)

    val finalRDD: RDD[(String, List[(String, String, Int)])] = changeAfterRDD.groupBy(_._1).mapValues(_.toList.sortWith(_._3 > _._3).take(3))


    //finalRDD.foreach(println)

    //输出结果
    finalRDD.foreach(perEle => {
      //println(s"省份名：${perEle._1}")

      //println("省份名\t广告id\t点击次数")
      for ((province, adid, cnt) <- perEle._2) {
        println("省份名→" + province + "\t广告id→" + adid + "\t点击次数→" + cnt)
      }

      //println("\n_____________________________\n")
    })

    //资源释放
    spark.stop
  }


  /**
    * 查看RDD的详情
    *
    * @param rdd
    */
  def showDetailInfo(rdd: RDD[(String, List[(String, String, Int)])]) = {
    rdd.mapPartitionsWithIndex((index, itr) => {

      val container: ListBuffer[(String, Int)] = new ListBuffer()

      itr.foreach(perEle => container.append((perEle._1 + "" + perEle._2.toBuffer.toString, index)))

      container.toList.toIterator
    }).foreach(println)
  }
}
