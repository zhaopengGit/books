package com.l000phone.spark_core.day05.demo05_jdbcrdd

import java.sql.ResultSet

import com.l000phone.spark_core.day05.demo04_file.sample02_sequencefile.SequnceFileDemo
import com.l000phone.util.DbcpUtil
import org.apache.spark.SparkContext
import org.apache.spark.rdd.{JdbcRDD, RDD}
import org.apache.spark.sql.SparkSession

/**
  * Description：JDBCRDD演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
object JdbcRDDDemo {
  def main(args: Array[String]): Unit = {
    //①SparkSession
    val spark: SparkSession = SparkSession.builder.
      appName(SequnceFileDemo.getClass.getSimpleName).
      master("local[*]").
      getOrCreate


    /**
      *
      * sc: SparkContext,
      * getConnection: () => Connection,
      * sql: String,
      * lowerBound: Long,
      * upperBound: Long,
      * numPartitions: Int,
      * mapRow: (ResultSet) => T = JdbcRDD.resultSetToObjectArray _)
      *
      */

    val sc: SparkContext = spark.sparkContext
    val conn = () => DbcpUtil.getConnection
    val sql: String = "SELECT  province,`hour`,adId,cnt FROM tb_ad_result where id between ? and ?"

    val rdd: RDD[(String, Int, Int, Int)] = new JdbcRDD(
      sc,
      conn,
      sql,
      5,
      10,
      1,
      fun
    )

    rdd.foreach(println)


    //③释放资源
    //关闭连接，resultSet等等
    spark.stop
  }

  /**
    * 声明式的函数，接收查询后的返回值
    */
  val fun = (rs: ResultSet) => {
    val province = rs.getString("province")
    val hour = rs.getInt("hour")
    val adId = rs.getInt("adId")
    val cnt = rs.getInt("cnt")
    (province, hour, adId, cnt)
  }
}
