package com.l000phone.spark_core.day02.demo01_transformation

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
  * Description：RDD常用的转换算子演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月25日
  *
  * @author 徐文波
  * @version : 1.0
  */
object CommonTransformationDemo {
  def main(args: Array[String]): Unit = {
    //步骤：
    //1、SparkSession的实例
    val spark: SparkSession = SparkSession.
      builder.appName(CommonTransformationDemo.getClass.getSimpleName).
      master("local[*]").
      getOrCreate()

    val sc: SparkContext = spark.sparkContext



    //2、分别演示RDD常用的转换算子
    //0，a)  RDD创建方式之makeRDD
    // val rdd :RDD[Int]= sc.makeRDD(Seq(1,2,3,4,5))
    //println(s"RDD中所有元素的和是：${rdd.reduce(_+_)}")

    //   a)  RDD创建方式之makeRDD
    // val rdd :RDD[Int]= sc.parallelize(Seq(1,2,3,4,5))
    //println(s"→ RDD中所有元素的和是：${rdd.reduce(_+_)}")

    //①演示Transformation算子和Action算子的异同点
    //trasformationAndActionDiff(sc)

    //②map:返回一个新的RDD，该RDD由每一个输入元素经过func函数转换后组成
    //var rdd: RDD[Int] = sc.parallelize(Seq(1, 2, 3, 4, 5))
    //需求：将rdd中所有的元素乘以2，并输出
    //println(rdd.map(_*2).collect.toBuffer)

    println("\n_____________________________________________________\n")

    //③filter(func)  返回一个新的RDD，该RDD由经过func函数计算后返回值为true的输入元素组成
    //需求：rdd中所有的偶数筛选出来，并显示输出
    //println(rdd.filter(_ % 2 ==0).collect.toBuffer)

    println("\n_____________________________________________________\n")

    //④ sample, 采样的算子，根据fraction指定的比例对数据进行采样，可以选择是否使用随机数进行替换，seed用于指定随机数生成器种子
    //var rdd2: RDD[Int] = sc.parallelize(1 to 10)
    //第一个参数：true→允许重复，允许放回；false→不允许重复，不放回
    //第二个参数：采样率，对应的采样数 = 原来rdd中元素的个数* 采样率，此处是一个近似值，不是一个确定值
    // println(s"采样后的结果是：${rdd2.sample(false,0.5).collect.toBuffer}")

    println("\n_____________________________________________________\n")

    //⑤ intersection(otherDataset)    对源RDD和参数RDD求交集后返回一个新的RDD
    //var rdd1: RDD[Int] = sc.parallelize(7 to 8)
    //var rdd2: RDD[Int] = sc.parallelize(1 to 10)
    //(rdd1 intersection rdd2).foreach(println)

    println("\n_____________________________________________________\n")

    //⑥distinct: 对源RDD进行去重后返回一个新的RDD
    //var rdd: RDD[Int] = sc.parallelize( Seq(1,1,2,2,3,3,4,5))
    //rdd.distinct.foreach(println)

    println("\n_____________________________________________________\n")

    //⑦ join(otherDataset, [numTasks])     在类型为(K,V)和(K,W)的RDD上调用，返回一个相同key对应的所有元素对在一起的(K,(V,W))的RDD，前提：RDD中的元素类型是对偶元组
    //var rdd: RDD[(Int, String)] = sc.parallelize(Seq((1, "张三"), (2, "刘德华"), (3, "张学友")))
    //var rdd2: RDD[(Int, Int)] = sc.parallelize(Seq((1, 38), (2, 56), (4, 29)))
    //var resultRDD:RDD[(Int,(String,Int))] = rdd.join(rdd2)
    //resultRDD.foreach(println)

    println("\n_____________________________________________________\n")
    //⑧union(otherDataset)                                    对源RDD和参数RDD求并集后返回一个新的RDD
    //(sc.parallelize(7 to 8) union sc.parallelize(8 to 10)).foreach(println)

    println("\n_____________________________________________________\n")
    //⑨leftOuterJoin       两个RDD进行左外连接查询，None
    //var rdd: RDD[(Int, String)] = sc.parallelize(Seq((1, "张三"), (2, "刘德华"), (3, "张学友")))
    //var rdd2: RDD[(Int, Int)] = sc.parallelize(Seq((1, 38), (2, 56), (4, 29)))
    //var resultRDD:RDD[(Int,(String,Option[Int]))] = rdd.leftOuterJoin(rdd2)
    //resultRDD.foreach(perEle=>println(perEle._1+"\t"+perEle._2._1+"\t"+perEle._2._2.getOrElse(-1)))

    println("\n_____________________________________________________\n")
    //⑩groupBy  分组
    //var rdd: RDD[(Int,String)] = sc.parallelize( Seq((1,"jack"),(1,"marry"),(2,"tom")))
    //rdd.groupBy(_._1).foreach(println) //没有本地聚合的操作，需要手动指定分组的依据值， rdd中每个元素形如：(1,CompactBuffer((1,jack), (1,marry)))

    // groupByKey 在一个(K,V)的RDD上调用，返回一个(K, Iterator[V])的RDD，没有本地聚合。都是全局聚合
   //var rdd: RDD[(Int, String)] = sc.parallelize(Seq((1, "jack"), (1, "marry"), (2, "tom")))
   //rdd.groupByKey.foreach(println) //rdd中每个元素形如：(1,CompactBuffer(jack, marry))


    println("\n_____________________________________________________\n")
    //11）cogroup 不需要对数据先进行合并就以进行分组 得到的结果是 同一个key 和不同数据集中的数据集合
    var rdd: RDD[(Int, String)] = sc.parallelize(Seq((1, "jack"), (1, "marry"), (2, "tom")))
    var rdd2: RDD[(Int, String)] = sc.parallelize(Seq((1, "上海"), (1, "北京"), (2, "深圳")))
    var resultRDD:RDD[(Int, (Iterable[String], Iterable[String]))] =rdd.cogroup(rdd2)
    resultRDD.foreach(println) //结果形如： (1,(CompactBuffer(jack, marry),CompactBuffer(上海, 北京)))

    //3、释放资源
    spark.stop
  }


  /**
    * ①演示Transformation算子和Action算子的异同点
    *
    * @param sc
    */
  private def trasformationAndActionDiff(sc: _root_.org.apache.spark.SparkContext) = {
    println(s"→ flatMap方法执行了哦！此时的线程名是：${Thread.currentThread.getName}")

    sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\wc\\hello.txt")

      .flatMap(perEle => {
        println(s"flatMap方法执行了哦！此时的线程名是：${Thread.currentThread.getName}")
        perEle.split("\\s+")
      })
      .map(perEle => {
        println(s"map方法执行了哦！此时的线程名是：${Thread.currentThread.getName}")
        (perEle, 1)
      }).foreach(perEle => {
      println(s"foreach方法执行了哦！此时的线程名是：${Thread.currentThread.getName}")
      println(perEle)
    })
  }
}
