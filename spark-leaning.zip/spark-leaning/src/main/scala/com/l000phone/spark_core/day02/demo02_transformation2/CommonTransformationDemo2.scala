package com.l000phone.spark_core.day02.demo02_transformation2

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.{HashPartitioner, SparkContext}

import scala.collection.mutable.ListBuffer

/**
  * Description：RDD常用的转换算子演示Ⅱ<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月25日
  *
  * @author 徐文波
  * @version : 1.0
  */
object CommonTransformationDemo2 {


  def main(args: Array[String]): Unit = {
    //步骤：
    //1、SparkSession的实例
    val spark: SparkSession = SparkSession.
      builder.appName(CommonTransformationDemo2.getClass.getSimpleName).
      master("local[*]").
      getOrCreate()

    val sc: SparkContext = spark.sparkContext


    //2、分别演示RDD常用的转换算子
    //①mapPartitions 类似于map，但独立地在RDD的每一个分片上运行，因此在类型为T的RDD上运行时，func的函数类型必须是Iterator[T] => Iterator[U]
    //mapPartitionsDo(sc)

    println("\n___________________________________________\n")
    //② mapPartitionsWithIndex  类似于mapPartitions，但func带有一个整数参数表示分片的索引值，因此在类型为T的RDD上运行时，func的函数类型必须是(Int, Iterator[T]) => Iterator[U]
    //mapPartitionsWithIndexDo(sc)

    println("\n___________________________________________\n")

    //③   sortByKey([ascending], [numTasks])          在一个(K,V)的RDD上调用，K必须实现Ordered接口，返回一个按照key进行排序的(K,V)的RDD
    //val rdd: RDD[(Int, String)] = sc.parallelize(List((1, "张三丰"), (3, "Marry"), (2, "Andy")))
    //rdd.sortByKey(false,1).foreach(println) //排序时，在各个分区中是有序的，若是希望全局有序，需要指定分区数是1


    println("\n___________________________________________\n")

    //④repartition(numPartitions)                         重新分区
    //coalesce(numPartitions)                             重新分区
    //val rdd: RDD[Int] = sc.parallelize(List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11), 3)
    //println("重新分区之前，RDD中的元素详情如下：")
    //showRDDDetail(rdd)

    ////val rddNew: RDD[Int] = rdd.filter(_ % 2 != 0).repartition(2)
    //val rddNew: RDD[Int] = rdd.filter(_ % 2 != 0).coalesce(2,false)
    //println(s"重新分区之后，分区数是：${rddNew.partitions.length},RDD中的元素详情如下：")
    //showRDDDetail(rddNew)

    println("\n___________________________________________\n")

    //⑤partitionBy : 根据指定的分区规则对RDD中的元素进行分区
    //val rdd: RDD[(String, Int)] = sc.parallelize(List(("a", 1), ("b", 2), ("c", 3)))
    //val rddNew = rdd.partitionBy(new HashPartitioner(3))
    //showRDDDetail2(rddNew)
    //println("→→→→→→")
    //showRDDDetail2(sc.parallelize(List(("a", 1), ("b", 2), ("c", 3)),3))

    println("\n___________________________________________\n")

    //③repartitionAndSortWithinPartitions(partitioner) 重新分区和排序，在给定的partitioner内部进行排序，性能比repartition要高
    //等价于： repartition + sortBy
    val rdd: RDD[(String, Int)] = sc.parallelize(List(("c", 1), ("b", 2), ("m", 4)))
    rdd.repartitionAndSortWithinPartitions(new HashPartitioner(1)).foreach(println)


    //3、释放资源
    spark.stop
  }

  /**
    *
    * mapPartitionsWithIndex  类似于mapPartitions，但func带有一个整数参数表示分片的索引值，因此在类型为T的RDD上运行时，func的函数类型必须是(Int, Iterator[T]) => Iterator[U]
    *
    * @param sc
    */
  def mapPartitionsWithIndexDo(sc: SparkContext) = {
    val rdd: RDD[Int] = sc.parallelize(Seq(1, 2, 3, 4, 5), 2)

    //匿名函数书写方式（一般这么做）
    //    val resultRDD: RDD[(Int,Int)] =  rdd.mapPartitionsWithIndex((index,itr) => {
    //      //临时容器
    //      val container: ListBuffer[(Int,Int)] = ListBuffer()
    //
    //      //从迭代器中依次取出元素，置于容器中
    //      itr.foreach(perEle=>container.append((perEle,index)))
    //
    //      //将容器中的数据置于新的迭代器中，并返回
    //      container.toIterator
    //    })

    val resultRDD: RDD[(Int, Int)] = rdd.mapPartitionsWithIndex(fun)

    resultRDD.foreach(println)
  }


  /**
    * 查看RDD元素的详情
    *
    * @param rdd
    */
  def showRDDDetail(rdd: RDD[Int]) = {
    val resultRDD: RDD[(Int, Int)] = rdd.mapPartitionsWithIndex((index, itr) => {
      //临时容器
      val container: ListBuffer[(Int, Int)] = ListBuffer()

      //从迭代器中依次取出元素，置于容器中
      itr.foreach(perEle => container.append((perEle, index)))

      //将容器中的数据置于新的迭代器中，并返回
      container.toIterator
    })

    resultRDD.foreach(println)
  }

  /**
    * 查看RDD元素的详情
    *
    * @param rdd
    */
  def showRDDDetail2(rdd: RDD[(String, Int)]) = {
    val resultRDD: RDD[(String, Int)] = rdd.mapPartitionsWithIndex((index, itr) => {
      //临时容器
      val container: ListBuffer[(String, Int)] = ListBuffer()

      //从迭代器中依次取出元素，置于容器中
      itr.foreach(perEle => container.append((perEle._1 + "→" + perEle._2, index)))

      //将容器中的数据置于新的迭代器中，并返回
      container.toIterator
    })

    resultRDD.foreach(println)
  }


  /**
    * 声明式的有名函数
    *
    */
  val fun = (index: Int, itr: Iterator[Int]) => {
    //临时容器
    val container: ListBuffer[(Int, Int)] = ListBuffer()

    //从迭代器中依次取出元素，置于容器中
    itr.foreach(perEle => container.append((perEle, index)))

    //将容器中的数据置于新的迭代器中，并返回
    container.toIterator
  }


  /**
    * 案例1： mapPartitions 类似于map，但独立地在RDD的每一个分片上运行，因此在类型为T的RDD上运行时，func的函数类型必须是Iterator[T] => Iterator[U]
    *
    * @param sc
    */
  def mapPartitionsDo(sc: SparkContext) = {
    val rdd: RDD[Int] = sc.parallelize(Seq(1, 2, 3, 4, 5), 2)
    val resultRDD: RDD[Int] = rdd.mapPartitions(itr => { //该方法每执行一次，将RDD中一个分区的数据拿出来，置于Iterator迭代器中，处理完毕之后，返回一个新的迭代器
      //临时容器
      val container: ListBuffer[Int] = ListBuffer()

      //从迭代器中依次取出元素，置于容器中
      itr.foreach(perEle => container.append(perEle * 2))

      //println("→ " + container)

      //将容器中的数据置于新的迭代器中，并返回
      container.toIterator
    })

    resultRDD.foreach(println)
  }

}
