package com.l000phone.spark_core.day03.demo01_transformation

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ListBuffer

/**
  * Description：常用的Transformation算子演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月26日
  *
  * @author 徐文波
  * @version : 1.0
  */
object TransformationDemo {


  def main(args: Array[String]): Unit = {
    //①SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(TransformationDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext


    //②算子演示
    //a) aggregateByKey(zeroValue)(seqOp, combOp, [numTasks]) 相同的Key值进行聚合操作，在聚合过程中同样使用了一个中立的初始值zeroValue:中立值,定义返回value的类型，
    //并参与运算seqOp:用来在同一个partition中合并值combOp:用来在不同partiton中合并值
    //aggregateByKeyDo(sc)

    println("\n_______________________________________________________\n")

    //b) conbineByKey
    conbineByKeyDo(sc)

    println("\n_______________________________________________________\n")

    //c) filterByRange 根据指定的上下边界来筛选RDD中的元素，要求源rdd中每个元素类型是对偶元组。该算子属于transformation算子
    val tupleRDD: RDD[(String, Int)] = sc.parallelize(List(("e", 5), ("c", 3), ("d", 4), ("c", 2), ("a", 1)))
    tupleRDD.filterByRange("c", "e").foreach(println)

    println("\n_________________________________________________\n")
    //d flatMapValues  将源rdd中每个元素（对偶元组）的值根据指定的规则切分为集合，然后压平，与共同的key组合成一个元组 ,置于一个全新的rdd中。该算子属于transformation算子
    val tupleRDD2: RDD[(Int, String)] = sc.parallelize(Seq((1, "hello you"), (2, "are you   ok"), (3, "hell    marry")))
    // val resultRDD:RDD[(Int,String)] = tupleRDD2.flatMapValues( _.split("\\s+"))
    val resultRDD: RDD[(Int, String)] = tupleRDD2.flatMapValues(perEle => {
      println("执行了没有？。。。。")
      perEle.split("\\s+")
    })
    resultRDD.foreach(println)


    println("\n_________________________________________________\n")
    //d) keyBy:  将该算子运行的结果作为新的元组中每个元素的key，value是源元组中的每个元素。 该算子属于transformation算子
    val rddString:RDD[String] = sc.parallelize(List("are","you","ok"))
    val resultRDD2:RDD[(Int,String)] = rddString.keyBy(_.length)
    resultRDD2.foreach(println)

    println("\n_________________________________________________\n")
    //e) keys → 将源rdd中所有元素（类型是对偶元组）的key拿到一个全新的rdd中 。 该算子属于transformation算子
    //   values→  将源rdd中所有元素（类型是对偶元组）的value拿到一个全新的rdd中。 该算子属于transformation算子
    resultRDD2.keys.foreach(println)
    resultRDD2.values.foreach(println)



    //③资源释放
    spark.stop

  }


  /**
    *
    * @param sc
    */
  def conbineByKeyDo(sc: SparkContext) = {
    val rdd: RDD[(String, Int)] = sc.parallelize(List(("cat", 2), ("cat", 5), ("pig", 10), ("dog", 3), ("dog", 4), ("cat", 4)), 2)

    //需求：将每个分区中的最大值累加起来
    showDetailInfo2(rdd)


    val resultRDD: RDD[(String, Int)] = rdd.combineByKey(x=>x,(x:Int,y:Int)=>x+y,_+_)


    showDetailInfo2(resultRDD)


    resultRDD.foreach(println)


   //(cat~2,0)
   //(dog~3,1)
   //(cat~5,0)
   //(dog~4,1)
   //(pig~10,0)
   //(cat~4,1)
   //------------------------
    // 0号分区：(cat~7，0)， (pig~10,0)
    //1号分区：(dog~7，1)，(cat~4,1)

   //(dog~7,0)
   //(pig~10,0)
   //(cat~11,0)

   //(dog,7)
   //(pig,10)
   //(cat,11)
  }


  /**
    * a) aggregateByKey(zeroValue)(seqOp, combOp, [numTasks]) 相同的Key值进行聚合操作，在聚合过程中同样使用了一个中立的初始值zeroValue:中立值,定义返回value的类型，
    * 并参与运算seqOp:用来在同一个partition中合并值combOp:用来在不同partiton中合并值
    *
    */
  def aggregateByKeyDo(sc: SparkContext) = {
    val rdd: RDD[(String, Int)] = sc.parallelize(List(("cat", 2), ("cat", 5), ("pig", 10), ("dog", 3), ("dog", 4), ("cat", 4)), 2)

    //需求：将每个分区中的最大值累加起来
    showDetailInfo2(rdd)


    //(cat~2,0)
    //(cat~5,0)
    //(pig~10,0)
    //初始值是0 → (cat~5,0) ，(pig~10,0)

    //初始值是10， → (cat~10,0) ，(pig~10,0)


    //(dog~4,1)
    //(dog~3,1)
    //(cat~4,1)
    //初始值是0   →  (dog~4,0)，  (cat~4,0)
    //初始值是10， →  (dog~10,0)，  (cat~10,0)

    //根据key聚合：
    //初始值是：0
    // (cat~9,0)
    // (pig~10,0)
    // (dog~4,0)

    //初始值是：10
    // (cat~20,0)
    // (pig~10,0)
    // (dog~10,0)


    //心得：根据各个分区中的key进行分组，然后针对每个每组中的值根据局部规则进行计算，计算后的结果置于全局的新的分组中 （一个分区）


    val resultRDD: RDD[(String, Int)] = rdd.aggregateByKey(10)(math.max(_, _), _ + _)


    showDetailInfo2(resultRDD)

    println("------------")


    resultRDD.foreach(println)
  }

  /**
    * 查看RDD的详情
    *
    * @param rdd
    */
  def showDetailInfo2(rdd: RDD[(String, Int)]) = {
    rdd.mapPartitionsWithIndex((index, itr) => {

      val container: ListBuffer[(String, Int)] = new ListBuffer()
      itr.foreach(perEle => container.append((perEle._1 + "~" + perEle._2, index)))

      container.toList.toIterator
    }).foreach(println)
  }


  /**
    * 查看RDD的详情
    *
    * @param rdd
    */
  def showDetailInfo(rdd: RDD[Int]) = {
    rdd.mapPartitionsWithIndex((index, itr) => {

      val container: ListBuffer[(Int, Int)] = new ListBuffer()
      itr.foreach(perEle => container.append((perEle, index)))

      container.toList.toIterator
    }).foreach(println)
  }

}
