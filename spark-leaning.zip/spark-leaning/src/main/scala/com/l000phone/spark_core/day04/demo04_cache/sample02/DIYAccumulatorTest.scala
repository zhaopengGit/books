package com.l000phone.spark_core.day04.demo04_cache.sample02

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object DIYAccumulatorTest {
  def main(args: Array[String]): Unit = {
    val spark:SparkSession = SparkSession.builder()
      .appName(DIYAccumulatorTest.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate()

    val sc:SparkContext = spark.sparkContext
    //============================================================================
    //自定义累加器
    val myacc = new DIYAccumulator()
	//注册自定义累加器
    sc.register(myacc,"myAcc")

    val rdd:RDD[Int] = sc.parallelize(Seq(1,2,3,4,5,6,7,8,9,10),2)
    val rdd2 = rdd.map(perEle=>{
      myacc.add(perEle)
    }).cache()
    println(s"读取累加器的值；${myacc.value}")

    rdd2.count()

    println(s"读取累加器的值；${myacc.value}")

	//=======trap=======
    rdd2.count()

    println(s"读取累加器的值；${myacc.value}")
  }
}
