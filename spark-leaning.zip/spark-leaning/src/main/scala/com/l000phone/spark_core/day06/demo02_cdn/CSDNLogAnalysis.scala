package com.l000phone.spark_core.day06.demo02_cdn

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
  * Description：csdn网站后台日志文件分析<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月01日
  *
  * @author 徐文波
  * @version : 1.0
  */
object CSDNLogAnalysis {
  /**
    * 用来解析ip的正则表达式
    */
  val IPRegex = "((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))".r

  /**
    * 用来解析视频的正则表达式
    */
  val VideoRegex = "([0-9]+).mp4".r

  /**
    * 用来判断日志信息中包含了mp4
    */
  val IncludeVideoRegex = ".*([0-9]+).mp4.*".r


  /**
    * 匹配 http 响应码和请求数据大小
    */
  val HttpRegex = ".*\\s(200|206|304)\\s([0-9]+)\\s.*".r


  /**
    * 时间正则表达式
    */
  val TimeRegex = ".*(2017):([0-9]{2}):[0-9]{2}:[0-9]{2}.*".r


  /**
    *
    * @param args
    */
  def main(args: Array[String]): Unit = {
    //步骤：
    //前提：
    //0： SparkSession
    val spark: SparkSession = SparkSession
      .builder
      .master("local[*]")
      .appName(CSDNLogAnalysis.getClass.getSimpleName)
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //将日志文件装载进RDD
    val rdd: RDD[String] = sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\cdn\\cdn.txt").cache()

    //需求：
    //1,  计算独立IP数
    //calcStandaloneIpNums(rdd)

    //2，统计每个视频独立IP数
    //calPerVedioDiffIPNums(rdd)


    //3，统计一天中每个小时的流量
    calOneDayPerHourFlow(rdd)


    //释放资源
    spark.stop
  }

  /**
    * 统计一天中每个小时的流量
    *
    * @param rdd
    */
  private def calOneDayPerHourFlow(rdd: RDD[String]) = {
    //a)正则表达式用法探讨
    //val str ="115.192.186.231 HIT 19 [15/Feb/2017:00:12:12 +0800] \"GET http://cdn.v.abc.com.cn/140987.mp4 HTTP/1.1\" 206 950 \"http://m.8531.cn/news/556707.html?ismobilephone=1&t=1487068199113&from=timeline&isappinstalled=0&weixin_share_count=2\" \"Mozilla/5.0+(iPhone;+CPU+iPhone+OS+9_3_5+like+Mac+OS+X)+AppleWebKit/601.1.46+(KHTML,+like+Gecko)+Mobile/13G36+MicroMessenger/6.5.5+NetType/WIFI+Language/zh_CN\""
    //val TimeRegex(year,xyz )=str
    //println(s"year = $year, hour = $xyz ")

    //val HttpRegex(code,flow)=str
    //println(s"状态码 = $code, 流量 = $flow ")


    //方案1：当前年份所有月份所有天中每个小时的流量综合情况 （粒度粗）
    //textFile →  过滤掉非法的日志信息 →借助正则表达式，求每条日志信息中的小时，流量，rdd中每个元素形如：(小时，流量)
    //→ reduceByKey ,结果是：每个小时总的流量 →格式化输出，将流量的单位转换成G
    rdd.filter(line => line.matches(HttpRegex.regex) && line.matches(TimeRegex.regex))
      .map(line => {
        val TimeRegex(year, hour) = line
        val HttpRegex(code, flow) = line
        (hour, flow.toLong)
      }).reduceByKey(_ + _)
      .sortByKey(true, 1)
      .foreach(perEle => {
        val flow = perEle._2.toDouble / (1024 * 1024 * 1024)
        println(perEle._1 + "\t\t" + flow + "G")
      })
  }

  /**
    * 统计每个视频独立IP数
    *
    * @param rdd
    */
  def calPerVedioDiffIPNums(rdd: RDD[String]) = {
    //textFile →  借助正则表达式，筛选出所有的视频日志 ，将RDD中每个元素变形为（视频名, ip）
    //→  根据视频名进行分组 → 对值进行去重，求总数目

    //筛选出所有的视频日志的必要性 →
    //rdd.filter(_.matches(IncludeVideoRegex.regex)).foreach(println)
    //val str="100.79.121.48 HIT 33 [15/Feb/2017:00:00:46 +0800] \"GET http://cdn.v.abc.com.cn/videojs/video.js HTTP/1.1\" 200 174055 \"http://www.abc.com.cn/\" \"Mozilla/4.0+(compatible;+MSIE+6.0;+Windows+NT+5.1;+Trident/4.0;)\""
    //val str="115.192.186.231 HIT 19 [15/Feb/2017:00:12:12 +0800] \"GET http://cdn.v.abc.com.cn/140987.mp4 HTTP/1.1\" 206 950 \"http://m.8531.cn/news/556707.html?ismobilephone=1&t=1487068199113&from=timeline&isappinstalled=0&weixin_share_count=2\" \"Mozilla/5.0+(iPhone;+CPU+iPhone+OS+9_3_5+like+Mac+OS+X)+AppleWebKit/601.1.46+(KHTML,+like+Gecko)+Mobile/13G36+MicroMessenger/6.5.5+NetType/WIFI+Language/zh_CN\""
    //println(VideoRegex.findFirstIn(str).get)

    rdd.filter(_.matches(IncludeVideoRegex.regex))
      .map(line => (VideoRegex.findFirstIn(line).get, IPRegex.findFirstIn(line).get)) //注意：若是使用神奇的下划线报错，此时，不能简写函数，需要还原
      .groupByKey()
      .mapValues(_.toList.distinct.size)
      .sortBy(_._2, false, 1)
      .foreach(println)

  }


  /**
    * 计算独立IP数
    *
    * @param rdd
    */
  def calcStandaloneIpNums(rdd: RDD[String]) = {

    //val logInfo = "61.175.198.153 HIT 28 [15/Feb/2017:00:04:14 +0800] \"GET http://cdn.v.abc.com.cn/videojs/video-js.css HTTP/1.1\" 200 48575 \"http://www.abc.com.cn/\" \"Mozilla/5.0+(compatible;+heritrix/3.1.0++http://localhost)\""

    // println(s"日志行中分离出来的ip地址是：${IPRegex.findFirstIn(logInfo).get}")

    //textFile → 借助正则表达式，将每行数据变形为，（ip地址，1） → reduceByKey  → 前10个最为活跃的ip地址，独立的ip总数

    val rddSum: RDD[(String, Int)] = rdd.map(line => (IPRegex.findFirstIn(line).get, 1))
      .reduceByKey(_ + _)

    val ipNum: Long = rddSum.count

    println(s"独立的ip数是：$ipNum")
    println("\n________________________________________\n")

    println("前10个最活跃的ip是：")
    rddSum.sortBy(_._2, false, 1)
      .take(10)
      .foreach(println)


  }
}
