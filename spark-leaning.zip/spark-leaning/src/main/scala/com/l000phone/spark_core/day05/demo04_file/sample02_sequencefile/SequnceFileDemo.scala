package com.l000phone.spark_core.day05.demo04_file.sample02_sequencefile

import com.alibaba.fastjson.JSON
import com.l000phone.entity.Student
import org.apache.spark.sql.SparkSession

/**
  * Description：JSON文件的读取,以sequncefile的形式写出<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SequnceFileDemo {
  def main(args: Array[String]): Unit = {
    //①SparkSession
    val spark: SparkSession = SparkSession.builder.
      appName(SequnceFileDemo.getClass.getSimpleName).
      master("local[*]").
      getOrCreate

    //②读取json格式的数据为rdd
    spark.sparkContext.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\json\\stu.json")
      .map(perLine => {
        val stu: Student = JSON.parseObject(perLine, classOf[Student])
        (stu.getId, stu.getName, stu.getAddress)
      })
      .map(perEle => {
        val newAddr = "→" + perEle._3
        (perEle._1, perEle._2 + " - " + newAddr)
      }).saveAsSequenceFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sequence")

    //③释放资源
    spark.stop
  }
}
