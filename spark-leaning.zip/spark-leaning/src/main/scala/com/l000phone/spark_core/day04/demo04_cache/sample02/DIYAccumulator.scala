package com.l000phone.spark_core.day04.demo04_cache.sample02

import org.apache.spark.util.AccumulatorV2

class DIYAccumulator extends AccumulatorV2[Int,Int]{
  //准备容器(存储最终输出值)
  var sum:Int = _

  /**
    * 用于判断累加后是否为空
    * @return
    */
  override def isZero: Boolean = sum==0

  /**
    * 将当前累加器的实例准备一个副本，将该累加器的实例传递到多个线程中（一个线程对应一个累加器）
    * @return
    */
  override def copy(): AccumulatorV2[Int,Int] = {
    val newAcc = new DIYAccumulator
    //newAcc.container.addAll(container)
    newAcc.sum = this.sum
    newAcc
  }

  /**
    * 重置累加器中的元素
    */
  override def reset(): Unit = sum = 0

  /**
    * 具体进行累加的操作(局部累加)
    * @param v
    */
  override def add(v: Int): Unit = sum+=v

  /**
    * 将当前累加器中的元素与参数传入的累加器中的元素合并起来（全局累加：==>合并每一个分区的累加值）
    * @param other
    */
  override def merge(other: AccumulatorV2[Int, Int]): Unit = sum+=other.value

  /**
    * 在Driver进程中调用
    * @return
    */
  override def value: Int = sum
}
