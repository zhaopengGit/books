package com.l000phone.spark_core.day04.demo04_cache.sample01

import java.net.URL

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
  * Description：根据用访问数据进行统计，用户对各个学科的各个模块的访问量Top3,使用缓存<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月27日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SubjectCacheDemo {
  def main(args: Array[String]): Unit = {
    //步骤：

    //前提：
    //println(s"域名信息是：${getDomainName("http://h5.learn.com/h5/teacher.shtml")}");

    //①SparkSession
    val spark: SparkSession = SparkSession.builder.
      appName(SubjectCacheDemo.getClass.getSimpleName).
      master("local[*]").
      getOrCreate

    //②分析RDD,20201123101523	http://java.learn.com/java/javaee.shtml
    calaSubjectTop3Module(spark)

    //③释放资源
    spark.stop
  }

  /**
    *
    * 计算各个学科方向最受欢迎的前3个module
    *
    * @param spark
    */
  private def calaSubjectTop3Module(spark: SparkSession) = {

    //1，通过集合模拟从db中读取了该培训机构所有学科名
    val allSubjectNames = List("http://android.learn.com", "http://ui.learn.com", "http://h5.learn.com", "http://java.learn.com", "http://bigdata.learn.com")


    //2,RDD分析
    //①将所有学科对应的所有模块访问的次数对应的RDD缓存起来
    val cacheRDD: RDD[(String, Int)] = spark.sparkContext.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\subject")
      .map(perEle => {
        val arr = perEle.split("\\s+")
        val url = arr(1).trim
        (url, 1)
      }).reduceByKey(_ + _).cache

    //②从数据中依次取出学科信息，与rdd中每个元素进行比对，筛选出当前学科的模块信息，求top4,并显示出来
    for (subjectName <- allSubjectNames) {
      val startTime = System.currentTimeMillis
      cacheRDD.filter(_._1.startsWith(subjectName)).sortBy(_._2, false).take(3).foreach(println)
      val endTime = System.currentTimeMillis
      println(s"针对于主题$subjectName, 计算该主题下最受欢迎的三个模块信息，耗费的时间是：${endTime - startTime}ms")
    }
  }

  /**
    * 根据url获得域名信息
    *
    * @param url
    * @return
    */
  def getDomainName(url: String) = {
    new URL(url).getHost
  }
}
