package com.l000phone.spark_core.day04.demo03_subject

import java.net.URL

import org.apache.spark.sql.SparkSession

/**
  * Description：根据用访问数据进行统计，用户对各个学科的各个模块的访问量Top3<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月27日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SubjectDemo {
  def main(args: Array[String]): Unit = {
    //步骤：

    //前提：
    //println(s"域名信息是：${getDomainName("http://h5.learn.com/h5/teacher.shtml")}");

    //①SparkSession
    val spark: SparkSession = SparkSession.builder.
      appName(SubjectDemo.getClass.getSimpleName).
      master("local[*]").
      getOrCreate

    //②分析RDD,20201123101523	http://java.learn.com/java/javaee.shtml
    calaSubjectTop3Module(spark)

    //③释放资源
    spark.stop
  }

  /**
    *
    * 计算各个学科方向最受欢迎的前3个module
    *
    * @param spark
    */
  private def calaSubjectTop3Module(spark: SparkSession) = {
    spark.sparkContext.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\subject")
      .map(perEle => {
        val arr = perEle.split("\\s+")
        val url = arr(1).trim
        (url, 1)
      }).reduceByKey(_ + _)
      .map(perEle => {
        val url = perEle._1
        val subjectName = getDomainName(url)
        val moduleName = url.substring(url.lastIndexOf('/') + 1, url.lastIndexOf('.'))
        (subjectName, (moduleName, perEle._2))
      }).groupByKey().mapValues(_.toList.sortBy(_._2).reverse.take(3))
      .foreach(println)
  }

  /**
    * 根据url获得域名信息
    *
    * @param url
    * @return
    */
  def getDomainName(url: String) = {
    new URL(url).getHost
  }
}
