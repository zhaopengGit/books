package com.l000phone.spark_core.day03.demo03_sharevar

import java.util

import org.apache.spark.util.AccumulatorV2

/**
  * Description：自定义累加器<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月26日
  *
  * @author 徐文波
  * @version : 1.0
  */
class MyselfAccumulator extends AccumulatorV2[String, java.util.LinkedList[String]] {
  //准备容器
  var container: java.util.LinkedList[String] = new util.LinkedList


  /**
    * 用于判断累加后的结果是否为空
    *
    * @return
    */
  override def isZero: Boolean = container.isEmpty


  /**
    *
    * 将当前累加器的实例准备一个副本，将该累加器的实例传递到多个线程中 （一个线程对应一个累加器）
    *
    * @return
    */
  override def copy(): AccumulatorV2[String, java.util.LinkedList[String]] = {
    val newAcc = new MyselfAccumulator
    //newAcc.container.addAll(container)
    newAcc
  }

  /**
    * 充值累加器中的元素
    */
  override def reset(): Unit = container.clear


  /**
    * 具体进行累加的操作
    *
    * @param v
    */
  override def add(v: String): Unit = container.add(v)

  /**
    * 将当前累加器中的元素与参数传入的累加器中的元素合并起来
    *
    * @param other
    */
  override def merge(other: AccumulatorV2[String, java.util.LinkedList[String]]): Unit = {
    val otherAcc = other.asInstanceOf[MyselfAccumulator]
    container.addAll(otherAcc.container)
  }

  /**
    * 在Driver进程中调用累加器实例.value方法，返回的是所有累加器合并后的结果
    *
    * @return
    */
  override def value: java.util.LinkedList[String] = container
}
