package com.l000phone.spark_core.day05.demo03_partition.sample01_simpleselfpartition

import org.apache.spark.Partitioner

/**
  * Description：自定义分区<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
class MyPartitioner(numPartition: Int) extends Partitioner {
  override def numPartitions: Int = numPartition

  /**
    * key对分区数求余，余数即为分区的编号
    *
    * @param key
    * @return
    */
  override def getPartition(key: Any): Int = key.toString.toInt % numPartition
}
