package com.l000phone.spark_core.day05.demo02_sort.sample02_ordering.case1_usecaseclass

/**
  * Description：单例对象<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
object MyPredef {
  /**
    * 准备了一个Ordering[Girl] 类型的隐式实例
    */
  implicit val girl: Ordering[Girl] = new Ordering[Girl] {
    /**
      * 定制比较规则
      *
      * 经验的总结：
      * 升序： 计算时第一个参数置于前
      * 降序： 计算时第二个参数置于前
      *
      * @param x
      * @param y
      * @return
      */
    override def compare(x: Girl, y: Girl): Int = {
      //判断颜值，颜值相同，判断年龄，年龄相同，再比较身高
      val faceComp = y.faceValue - x.faceValue
      if (faceComp == 0) {
        val ageComp = x.age - y.age
        if (ageComp == 0) {
          return (y.height - x.height).toInt
        }
        return ageComp
      }
      return faceComp
    }
  }
}
