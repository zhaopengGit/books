package com.l000phone.spark_core.day04.demo01_ad

import com.l000phone.dao.IADDao
import com.l000phone.dao.impl.ADDaoImpl
import com.l000phone.entity.ADResult
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.joda.time.DateTime

/**
  * Description： 统计每一个省份每一个小时的TOP3广告ID,且将最终计算后的结果落地到db中 <br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月27日
  *
  * @author 徐文波
  * @version : 1.0
  */
object PerProvincePerHourAdClickCnt2 {
  def main(args: Array[String]): Unit = {
    //1，SparkSession
    val spark: SparkSession = SparkSession.builder.
      appName(PerProvincePerHourAdClickCnt2.getClass.getSimpleName).
      master("local[*]").
      getOrCreate()

    val sc: SparkContext = spark.sparkContext


    //2，RDD分析，迭代计算
    sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\ad\\ad.txt")
      .map(_.split("\\s+"))
      .map(arr => { //1544406050000	广东省	深圳市	2	2
        val province = arr(1).trim
        val hour = getHour(arr(0).trim)
        val adId = arr(4)

        (province + "#" + hour + "#" + adId, 1)
      }).reduceByKey(_ + _)
      .map(perEle => {
        var arr = perEle._1.split("#")
        val province = arr(0).trim
        val hour = arr(1).trim
        val adId = arr(2).trim
        (province + "#" + hour, (adId, perEle._2))
      }).groupByKey().mapValues(_.toList.sortBy(_._2).reverse.take(3))
      .map(perEle => { //为了增强可读性，将同一个省份的结果放到一起
        val arr = perEle._1.split("#")
        val province = arr(0)
        val hour = arr(1)

        (province, (hour, perEle._2))
      }).groupByKey().foreachPartition(itr => {

      //准备Dao层的实例
      val dao: IADDao = new ADDaoImpl

      for (perEle <- itr) {
        val province = perEle._1
        for (tuple <- perEle._2) {
          val hour = tuple._1
          val lst = tuple._2
          for (sonEle <- lst) {
            val adId = sonEle._1
            val cnt = sonEle._2

            val entity: ADResult = new ADResult(province, hour.toInt, adId.toInt, cnt)
            dao.insert(entity)
          }
        }
      }


    })

    //(浙江省,CompactBuffer((4,List((5,2), (7,2))), (15,List((7,2), (8,1), (6,1))), (3,List((5,2))), (1,List((5,2)))))
    //(广东省,CompactBuffer((10,List((2,5))), (9,List((4,1), (2,1))), (14,List((4,4), (3,1))), (22,List((3,2))), (15,List((5,1), (2,1)))))

    //3，资源释放
    sc.stop
  }


  /**
    * 根据日期字符串获得小时
    *
    * @param timeStr
    * @return
    */
  def getHour(timeStr: String) = {
    new DateTime(timeStr.toLong).getHourOfDay
  }
}


