package com.l000phone.spark_sql.day02.demo09_sqlfunction.sample04_udafdemo

import org.apache.spark.sql.expressions.Aggregator
import org.apache.spark.sql.{Dataset, Encoder, Encoders, SparkSession}

/**
  * Description：UDAF函数支持Dataset(强类型)，需求：计算所有员工的平均薪水，不能使用官方avg。  <br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object UDAFDemo2 {
  def main(args: Array[String]): Unit = {
    //SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(UDAFDemo2.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    import spark.implicits._

    val ds: Dataset[Empoyee] = spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")
      .as[Empoyee]

    val column = new MyFun().toColumn.name("→ 平均工资")

    ds.select(column).show

    //资源释放
    spark.close
  }
}

//Employee样例类
case class Empoyee(address: String, id: BigInt, name: String, age: BigInt, salary: Double)

// 平均工资样例类
case class MyAvg2(var sum: Double,var  cnt: Int)

/**
  * 用户自定义UDAF函数
  *
  */
class MyFun extends Aggregator[Empoyee, MyAvg2, Double] {
  /**
    * 初始化
    *
    * @return
    */
  override def zero: MyAvg2 = MyAvg2(0.0, 0)

  /**
    * 当前Executor中的分区中的数据进行局部聚合
    *
    * @param b
    * @param a
    * @return
    */
  override def reduce(b: MyAvg2, a: Empoyee): MyAvg2 = {
    if (a.salary >= 0) {
      b.sum +=  a.salary
      b.cnt += 1
    }
    b
  }

  /**
    * 全局聚合
    *
    * 各个分区中的记录进行聚合
    *
    * @param b1
    * @param b2
    * @return
    */
  override def merge(b1: MyAvg2, b2: MyAvg2): MyAvg2 = {
    b1.sum += b2.sum
    b1.cnt += b2.cnt

    b1
  }

  /**
    * 求得最终的平均工资时回调该方法
    *
    * @param reduction
    * @return
    */
  override def finish(reduction: MyAvg2): Double = reduction.sum / reduction.cnt

  /**
    *
    * 为tuple,case class产生编码器的实例
    *
    * @return
    */
  override def bufferEncoder: Encoder[MyAvg2] = Encoders.product

  /**
    * 对最终输出的结果进行编码
    *
    * @return
    */
  override def outputEncoder: Encoder[Double] = Encoders.scalaDouble
}