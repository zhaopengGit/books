package com.l000phone.spark_sql.day02.demo09_sqlfunction.sample04_udafdemo

import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Row, SparkSession}

/**
  * Description：弱类型的UDAF演示，需求：计算所有员工的平均薪水，不能使用官方avg。  <br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object UDAFDemo {
  def main(args: Array[String]): Unit = {
    //SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(UDAFDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate


    spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")
      .createOrReplaceTempView("tb_emp")

    //注册
    spark.udf.register("myAvg", new MyAvg)

    spark.sql("select myAvg(salary) `平均薪水` from tb_emp").show


    //资源释放
    spark.close
  }
}


/**
  * 用户自定义UDAF函数
  *
  */
class MyAvg extends UserDefinedAggregateFunction {
  /**
    * 自定义函数输入的字段的类型对应的元数据信息
    *
    * @return
    */
  override def inputSchema: StructType = StructType(Seq(StructField("salary", DoubleType, false)))

  /**
    * 定制计算的那条记录中相应字段的元数据信息，就是下述的evaluate方法参数指定的Row的元数据信息
    *
    * @return
    */
  override def bufferSchema: StructType = StructType(Seq(StructField("sum", DoubleType, false), StructField("count", IntegerType, false)))

  /**
    * 当前自定义执行完毕之后返回值的自定义类型
    *
    * @return
    */
  override def dataType: DataType = DoubleType

  /**
    * 当前自定义函数的输入是否与时间相关，相关：false;不相关就是true
    *
    * @return
    */
  override def deterministic: Boolean = true

  /**
    * MutableAggregationBuffer继承自Row, 就是一条记录
    *
    * 要对当前记录的各个字段进行初始化
    *
    * @param buffer
    */
  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    // 当前记录的第一个字段，用于存储薪水总和
    buffer(0) = 0.0
    //当前记录的第二个字段，用于存储薪水总数
    buffer(1) = 0
  }

  /**
    * 用来进行局部聚合
    *
    * 每个Executor中的分区中的数据进行局部汇总
    *
    * @param buffer
    * @param input
    */
  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    //若是当前记录的薪水不是空
    if (!input.isNullAt(0)) {
      val nowSum = input.getAs[Double](0)
      buffer(0) = buffer.getDouble(0) + nowSum
      buffer(1) = buffer.getInt(1) + 1
    }
  }

  /**
    * 进行全局的聚合
    *
    * @param buffer1
    * @param buffer2
    */
  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {

    buffer1(0) = buffer1.getDouble(0) + buffer2.getAs[Double](0)
    buffer1(1) = buffer1.getInt(1) + buffer2.getAs[Int](1)

  }

  /**
    * 自定义函数最终的结果
    *
    * @param buffer
    * @return
    */
  override def evaluate(buffer: Row): Any = buffer.getDouble(0) / buffer.getInt(1)
}
