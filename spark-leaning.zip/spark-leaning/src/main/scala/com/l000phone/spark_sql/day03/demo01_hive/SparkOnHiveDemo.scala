package com.l000phone.spark_sql.day03.demo01_hive

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.permission.{FsAction, FsPermission}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

/**
  * Description：Spark on hive演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月03日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SparkOnHiveDemo extends App {
  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(SparkOnHiveDemo.getClass.getSimpleName)
    .master("local[*]")
    .enableHiveSupport //必须启用sparksql对hive的支持，否则不能操作hive表
    .getOrCreate

  //①初始化
  spark.sql("drop database if exists  spark_on_hive cascade")
  spark.sql("create database spark_on_hive")
  spark.sql("drop table if exists spark_on_hive.tb_emp")
  spark.sql("drop table if exists spark_on_hive.tb_external_info")
  spark.sql("drop table if exists spark_on_hive.tb_final_result")

  //②建表
  spark.sql(
    """
      |create table spark_on_hive.tb_emp(
      | name string,
      | age int,
      | isMarried boolean,
      | deptNo int
      |) row format delimited
      | fields terminated by ','
      | location 'hdfs://ns1/spark-sql/emp'
    """.stripMargin)

  spark.sql(
    """
      |create table spark_on_hive.tb_external_info(
      | name string,
      | height double
      |) row format delimited
      | fields terminated by ','
      | location 'hdfs://ns1/spark-sql/emp_external_info'
    """.stripMargin)

  //③内连接查询
  //spark.sql("select * from spark_on_hive.tb_emp").show
  //println("\n____________________________\n")
  //spark.sql("select * from spark_on_hive.tb_external_info").show

  val df: DataFrame = spark.sql(
    """
      |select
      | e.name,
      | e.age,
      | e.isMarried,
      | t.height
      |from spark_on_hive.tb_emp e, spark_on_hive.tb_external_info t
      |where e.name=t.name
    """.stripMargin)

  //④保存结果
  df.write.mode(SaveMode.Overwrite).saveAsTable("spark_on_hive.tb_final_result")
  println("\n______________________________\n")
  //给当前用户添加访问hdfs://ns1/spark-sql/final_result的权限
  val path = "hdfs://ns1/spark-sql/final_result2"
  df.write.mode(SaveMode.Overwrite).json(path)


  //资源释放
  spark.close
}
