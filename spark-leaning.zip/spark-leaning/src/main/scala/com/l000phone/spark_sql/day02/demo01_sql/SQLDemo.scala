package com.l000phone.spark_sql.day02.demo01_sql

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Description：SparkSQL编程方式之SQL演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SQLDemo extends App {
  //①SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(SQLDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  //②使用SQL的方式读取执行的资源文件，求出所有成年的员工信息
  //a) 加载资源到内存中的临时表DataFrame →映射为一张虚拟表
  val df: DataFrame = spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")

  //b)注册为一张虚拟表
  df.createOrReplaceTempView("tb_emp")

  //b)使用sql语句访问虚拟表，并显示结果
  var age = 18
  spark.sql(s"select * from tb_emp where age>=$age")
    .show

  println("\n___________________________\n")
  //验证跨越多个Session,否则报错：Exception in thread "main" org.apache.spark.sql.AnalysisException: Table or view not found: tb_emp; line 1 pos 14
  //spark.newSession().sql(s"select * from tb_emp where age<$age").show
  //注册为一张全局的虚拟表
  df.createOrReplaceGlobalTempView("tb_global_emp")
  spark.newSession().sql(s"select * from global_temp.tb_global_emp where age<$age").show


  //③资源释放
  spark.stop
}
