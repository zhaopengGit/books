package com.l000phone.spark_sql.day02.demo07_ds2df

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.parser.Feature
import org.apache.spark.sql.{Dataset, SaveMode, SparkSession}

/**
  * Description：Dataset转换成DataFrame演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object Dataset2DataFrameDemo {
  def main(args: Array[String]): Unit = {
    //SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(Dataset2DataFrameDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    import spark.implicits._

    val ds: Dataset[String] = spark.read.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")
    ds.rdd.map(line => {
      val instance: Empoyee = JSON.parseObject(line, classOf[Empoyee])
      instance
    }).toDS.show()

    //资源释放
    spark.close
  }

}


/**
  * 样例类
  */
case class Empoyee(address: String, id: Int, name: String, age: Int, salary: Int)
