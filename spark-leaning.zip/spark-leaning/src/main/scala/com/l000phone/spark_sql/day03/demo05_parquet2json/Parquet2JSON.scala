package com.l000phone.spark_sql.day03.demo05_parquet2json

import com.l000phone.spark_sql.day03.demo04_json2parquet.JSON2ParquetDemo
import org.apache.spark.sql.{SaveMode, SparkSession}

/**
  * Description：读取parquet格式的数据到DataFrame中，处理后落地到指定的json格式的目录中<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月03日
  *
  * @author 徐文波
  * @version : 1.0
  */
object Parquet2JSON extends App {
  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(JSON2ParquetDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  //读取资源是
  spark.read.parquet("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\parquet")
    .createOrReplaceTempView("tb_emp")

  spark.sql("select age+2 age,address,id,name,salary from tb_emp")
    .write.mode(SaveMode.Overwrite)
    . json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\json")

  //资源释放
  spark.close
}
