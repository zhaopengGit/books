package com.l000phone.spark_sql.day02.demo04_df2rdd

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}

/**
  * Description：将临时表转换成RDD<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object DataFrame2RDDDemo extends App {
  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(DataFrame2RDDDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  // 通过rdd方法直接将将临时表DataFrame转换成RDD
  val rowRDD: RDD[Row] = spark.sparkContext.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\scores.txt")
    .map(_.split("\\s+"))
    .map(arr => Row(arr(0).trim, arr(1).trim.toInt))

  val structType: StructType = StructType(Seq(
    StructField("name", StringType, false),
    StructField("score", IntegerType, false)
  ))


  val rdd: RDD[Row] = spark.createDataFrame(rowRDD, structType).rdd

  rdd.foreach(row => {
    val clsName = row.getAs[String]("name")
    val score = row.getAs[Int]("score")

    println(s"班级名：$clsName \t分数：$score")
  })

  //资源释放
  spark.close
}
