package com.l000phone.spark_sql.day02.demo03_rdd2df

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

/**
  * Description：RDD转换为DataFrame演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object RDD2DFDemo {

  /**
    * 学生样例类
    *
    * @param name
    * @param age
    */
  case class Student(name: String, age: Int)


  def main(args: Array[String]): Unit = {
    //SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(RDD2DFDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate


    val sc: SparkContext = spark.sparkContext

    //导入
    import spark.implicits._

    val rdd: RDD[(String, Int)] = spark.sparkContext.parallelize(Seq(("张无忌", 18), ("张学友", 16), ("张三丰", 80))).cache

    //方式1： case class方式
    rdd.map(perEle => Student(perEle._1, perEle._2))
      .toDF
      .show

    println("\n______________________________________\n")
    //方式2：  tuple方式
    val df: DataFrame = rdd.toDF("name", "age")
    df.show

    //显示临时表的元数据信息
    df.printSchema

    println("\n_________________________________________________\n")
    //方式3: 通过StructType直接指定Schema
    val rowRDD: RDD[Row] = sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\scores.txt")
      .map(_.split("\\s+"))
      .map(arr => Row(arr(0).trim, arr(1).trim.toInt))

    val structType: StructType = StructType(Seq(
      StructField("name", StringType, false),
      StructField("score", IntegerType, false)
    ))


    spark.createDataFrame(rowRDD, structType)
      .show

    //资源释放
    spark.close
  }
}
