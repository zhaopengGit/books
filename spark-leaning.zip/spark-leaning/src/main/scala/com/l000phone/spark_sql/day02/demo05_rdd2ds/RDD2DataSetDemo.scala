package com.l000phone.spark_sql.day02.demo05_rdd2ds

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Dataset, SparkSession}

/**
  * Description：RDD转换为DataSet演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object RDD2DataSetDemo {
  def main(args: Array[String]): Unit = {
    //SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(RDD2DataSetDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    import spark.implicits._

    // RDD转换为DataSet
    val rdd: RDD[Score] = spark.sparkContext.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\scores.txt")
      .map(line => {
        val arr = line.split("\\s+")
        Score(arr(0).trim, arr(1).toInt)
      })

    val ds: Dataset[Score] = rdd.toDS

    ds.show

    //资源释放
    spark.close
  }

}


/**
  * 分数样例类
  *
  * @param name
  * @param score
  */
case class Score(name: String, score: Int)