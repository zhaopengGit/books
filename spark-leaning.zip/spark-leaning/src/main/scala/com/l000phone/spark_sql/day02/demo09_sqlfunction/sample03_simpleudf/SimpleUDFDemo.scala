package com.l000phone.spark_sql.day02.demo09_sqlfunction.sample03_simpleudf

import org.apache.spark.sql.SparkSession

/**
  * Description：Spark SQL简单自定义函数<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SimpleUDFDemo extends App {
  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(SimpleUDFDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate


  //需求：定义一个自定义函数，求出Emp表中任意给定字符串类型的字段的长度，并予以显示。

  //①employees.json → RDD → DataFrame → tb_emp
  spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")
    .createOrReplaceTempView("tb_emp")

  //② 注册自定义函数

  //逻辑简单的自定义函数
  //spark.udf.register[Int, String]("getLen", (str: String) => str.length)

  // 逻辑复杂的自定义函数
  //自定的方法
  def getStrLen(str: String) = str.length

  spark.udf.register[Int, String]("getLen", (str: String) => getStrLen(str))

  //③在sql语句中直接使用自定义函数
  spark.sql("select name `员工名`, getLen(name) `长度` from tb_emp").show


  //资源释放
  spark.close
}
