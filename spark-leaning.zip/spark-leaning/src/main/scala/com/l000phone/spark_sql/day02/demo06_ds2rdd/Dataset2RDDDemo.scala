package com.l000phone.spark_sql.day02.demo06_ds2rdd

import org.apache.spark.sql.{Dataset, Encoders, SparkSession}

/**
  * Description：xxxx<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object Dataset2RDDDemo extends App {
  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(Dataset2RDDDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  import spark.implicits._

  //DataSet实例 → RDD
 val ds: Dataset[Score] = spark.createDataset(Seq(Score("class1",89),Score("class2",99)))
  ds.rdd.foreach(println)

  //资源释放
  spark.close
}


/**
  * 分数样例类
  *
  * @param name
  * @param score
  */
case class Score(name: String, score: Int)
