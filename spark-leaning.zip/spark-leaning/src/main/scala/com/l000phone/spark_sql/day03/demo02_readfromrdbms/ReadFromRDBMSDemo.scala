package com.l000phone.spark_sql.day03.demo02_readfromrdbms

import java.util.Properties

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.internal.StaticSQLConf.CATALOG_IMPLEMENTATION

/**
  * Description：读取RDBMS中特定表的数据到临时表DataFrame中<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月03日
  *
  * @author 徐文波
  * @version : 1.0
  */
object ReadFromRDBMSDemo {
  def main(args: Array[String]): Unit = {
    //SparkSession
    val spark: SparkSession = SparkSession.builder
      .appName(ReadFromRDBMSDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    //需求：读取dy db中的表数据tb_user_info
    //url: String, table: String, properties: Properties
    val properties: Properties = new Properties
    properties.put("driver", "com.mysql.jdbc.Driver")
    properties.put("user", "root")
    properties.put("password", "88888888")

    spark.read.jdbc("jdbc:mysql://NODE03:3306/dy?useUnicode=true&characterEncoding=utf-8", "tb_user_info", properties)
      .show

    //资源释放
    spark.close
  }

}
