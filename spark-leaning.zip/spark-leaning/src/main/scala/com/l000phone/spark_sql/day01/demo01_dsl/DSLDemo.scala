package com.l000phone.spark_sql.day01.demo01_dsl

import org.apache.spark.sql.SparkSession

/**
  * Description：数据操作方法之DSL(领域特定语言)，用得较少 <br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月01日
  *
  * @author 徐文波
  * @version : 1.0
  */
object DSLDemo {
  def main(args: Array[String]): Unit = {
    //0： SparkSession
    val spark: SparkSession = SparkSession
      .builder
      .master("local[*]")
      .appName(DSLDemo.getClass.getSimpleName)
      .getOrCreate

    //导入SparkSession实例中的implicits单例对象下的方法
    import spark.implicits._

    //使用DSL风格
    spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")
      .filter($"age" >= 18)
      .select("name", "age")
      .show

    //释放资源
    spark.stop
  }
}
