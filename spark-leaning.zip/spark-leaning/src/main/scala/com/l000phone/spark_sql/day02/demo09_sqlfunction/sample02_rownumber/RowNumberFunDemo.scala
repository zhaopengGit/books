package com.l000phone.spark_sql.day02.demo09_sqlfunction.sample02_rownumber

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}

/**
  * Description：Spark SQL中常用的开窗函数之row_number演示，分组求topN<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object RowNumberFunDemo extends App {
  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(RowNumberFunDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  //将各个班级学生考试的成绩装载到内存中RDD → DataFrame → 虚拟表 tb_score
  val rows: RDD[Row] = spark.sparkContext.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\scores.txt")
    .map(line => {
      val arr = line.split("\\s+")
      Row(arr(0).trim, arr(1).trim.toInt)
    })

  val structType: StructType = StructType(Seq(
    StructField("cname", StringType, false),
    StructField("score", IntegerType, false)
  ))

  spark.createDataFrame(rows, structType)
    .createOrReplaceTempView("tb_score")


  //  spark.sql(
  //    """
  //      |select
  //      | *
  //      |from
  //      |(
  //      | select
  //      |   *,
  //      |   row_number() over( partition by cname order by score desc) level
  //      | from tb_score) t
  //      |where t.level<=3
  //    """.stripMargin)
  //    .show


  // 上述代码可以简化为：
  spark.sql(
    """
      |select
      |   *,
      |   row_number() over( partition by cname order by score desc) level
      |from tb_score
      |having level<=3
    """.stripMargin)
    .show


  //资源释放
  spark.close
}
