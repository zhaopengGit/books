package com.l000phone.spark_sql.day02.demo08_df2ds

import org.apache.spark.sql.{Dataset, SparkSession}

/**
  * Description：DataFrame → Dataset演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object DataFrame2DatasetDemo extends App {
  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(DataFrame2DatasetDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  import spark.implicits._

  // DataFrame → Dataset
  val ds: Dataset[Emp] = spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")
    .as[Emp]

  ds.show

  //资源释放
  spark.close
}

/**
  * 样例类
  *
  * @param id
  * @param name
  * @param address
  * @param salary
  */
case class Emp(address: String, id: BigInt, name: String, age: BigInt, salary: BigInt)