package com.l000phone.spark_sql.day03.demo06_lac

import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

/**
  * Description： 基站停留时间TopN,使用spark sql实现<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月27日
  *
  * @author 徐文波
  * @version : 1.0
  */
object LocationDemo {

  /**
    * 日志信息对应的样例类
    *
    * @param phoneNum
    * @param accessTime
    * @param stationId
    * @param flg
    */
  case class Log(phoneNum: String, accessTime: Long, stationId: String, flg: Int)


  /**
    * 基站信息对于的样例类
    *
    * @param stationId
    * @param jingdu
    * @param weidu
    */
  case class Lac(stationId: String, jingdu: String, weidu: String)

  def main(args: Array[String]): Unit = {
    //0)前提： SparkSession
    val spark: SparkSession = SparkSession.builder.
      appName(LocationDemo.getClass.getSimpleName).
      master("local[*]").
      getOrCreate()


    val sc: SparkContext = spark.sparkContext

    //核心思路：
    import spark.implicits._

    //①日志信息 → RDD → DataFrame → tb_log → row_number,分组求top2
    sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\location\\log")
      .map(perLine => {
        val arr = perLine.split(",")
        Log(arr(0), arr(1).toLong, arr(2), arr(3).toInt)
      }).toDF.createOrReplaceTempView("tb_log")

    spark.sqlContext.cacheTable("tb_log")

    spark.sql(
      """
        |select
        |  phoneNum,
        |  stationId,
        |  sum(case flg when 1 then -accessTime when 0 then accessTime  end ) stayTime
        |from tb_log
        |group by phoneNum,stationId
      """.stripMargin).createOrReplaceTempView("tb_log2")

    //根据tb_log2虚拟表的phoneNum进行分组查询，根据stayTime进行降序排列，求top2
    spark.sql(
      """
        |select
        | phoneNum,
        | stationId,
        | stayTime,
        | row_number() over(partition by phoneNum order by stayTime desc) level
        |from tb_log2
        |having level<=2
      """.stripMargin).createOrReplaceTempView("tb_log3")


    //②基站信息 → RDD → DataFrame → tb_lac
    sc.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\location\\lac_info.txt")
      .map(perLine => {
        val arr = perLine.split(",")
        Lac(arr(0), arr(1), arr(2))
      }).toDF.createOrReplaceTempView("tb_lac")

    spark.sqlContext.cacheTable("tb_lac")

    //③上述两张表进行内连接查询
    //select * from tb_log l, tb_lac  la where l.stationId = la.stationId

    spark.sql(
      """
        |select
        | l.phoneNum `手机号码`,
        | l.stationId `基站id`,
        | l.stayTime `停留时长`,
        | lac.jingdu `经度`,
        | lac.weidu `维度`
        |from tb_log3 l, tb_lac lac
        |where l.stationId = lac.stationId
      """.stripMargin).show

    //    +-----------+--------------------+-----+----------+---------+
    //    |       手机号码|                基站id| 停留时长|        经度|       维度|
    //    +-----------+--------------------+-----+----------+---------+
    //    |18101056888|9F36407EAD8829FC1...|54000|116.304864|40.050645|
    //      |18688888888|9F36407EAD8829FC1...|51200|116.304864|40.050645|
    //      |18101056888|16030401EAFB68F1E...|97500|116.296302|40.032296|
    //      |18688888888|16030401EAFB68F1E...|87600|116.296302|40.032296|
    //      +-----------+--------------------+-----+----------+---------+


    //4）资源释放
    spark.stop
  }
}
