package com.l000phone.spark_sql.day02.demo09_sqlfunction.sample01_withfun

import org.apache.spark.sql.SparkSession

/**
  * Description：SparkSQL内置函数演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SparkSQLWithFunDemo extends App {

  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(SparkSQLWithFunDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  //求出Emp表（内存中的表）中所有人的平均年龄，年龄总和，最大年龄，最小年龄，总人数
  //a)注册临时表
  spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")
    .createOrReplaceTempView("tb_emp")

  //b)书写sql
  spark.sql(
    """
      |select
      | avg(age) `平均年龄`,
      | sum(age) `年龄总和`,
      | max(age) `最大年龄`,
      | min(age) `最小年龄`,
      | count(id) `总人数`
      |from tb_emp
    """.stripMargin)
    .show

  //资源释放
  spark.close
}
