package com.l000phone.spark_sql.day03.demo04_json2parquet

import org.apache.spark.sql.{SaveMode, SparkSession}

/**
  * Description：读取json格式的数据到DataFrame中，处理后落地到指定的parquet格式的目录中<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月03日
  *
  * @author 徐文波
  * @version : 1.0
  */
object JSON2ParquetDemo extends App {
  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(JSON2ParquetDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")
    .createOrReplaceTempView("tb_emp")

  spark.sql("select age+1 age,address,id,name,salary from tb_emp")
    .write.mode(SaveMode.Overwrite)
    .parquet("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\parquet")

  //资源释放
  spark.close
}
