package com.l000phone.spark_sql.day03.demo03_df2rdbms

import java.util.Properties

import org.apache.spark.sql.{SaveMode, SparkSession}

/**
  * Description：将内存中的DataFrame处理完毕后，将结果落地到RDBMS中<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月03日
  *
  * @author 徐文波
  * @version : 1.0
  */
object DataFrame2RDBMSDemo extends App {
  //SparkSession
  val spark: SparkSession = SparkSession.builder
    .appName(DataFrame2RDBMSDemo.getClass.getSimpleName)
    .master("local[*]")
    .getOrCreate

  //需求：读取dy db中的表数据tb_user_info
  //url: String, table: String, properties: Properties
  val properties: Properties = new Properties
  properties.put("driver", "com.mysql.jdbc.Driver")
  properties.put("user", "root")
  properties.put("password", "88888888")

  val url = "jdbc:mysql://NODE03:3306/dy?useUnicode=true&characterEncoding=utf-8"

  val tableName = "tb_user_info"

  spark.read.jdbc(url, tableName, properties)
    .createOrReplaceTempView("tb_user_info_memory")

  spark.sqlContext.cacheTable("tb_user_info_memory")

  spark.sql("select * from tb_user_info_memory").show

  spark.sql("select   concat('姓名→',name) name,concat('地址→',address) address,time from tb_user_info_memory")
    .write.mode(SaveMode.Append).jdbc(url, "tb_user_info", properties)

  //资源释放
  spark.close
}
