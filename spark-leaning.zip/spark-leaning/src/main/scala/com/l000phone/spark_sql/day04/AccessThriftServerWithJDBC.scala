package com.l000phone.spark_sql.day04

import java.sql.{DriverManager, ResultSet}

import org.apache.hive.jdbc.HiveDriver

/**
  * Description：使用JDBC的技术访问远程的spark SQL thrift server<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月04日
  *
  * @author 徐文波
  * @version : 1.0
  */
object AccessThriftServerWithJDBC extends App {
  //步骤：
  //①注册驱动
  classOf[HiveDriver]

  //②获得连接
  val conn = DriverManager.getConnection("jdbc:hive2://NODE01:10001/spark_on_hive", "root", "123")

  //③准备PreparedStatement的实例，并执行sql，处理结果
  val ps = conn.prepareStatement("select name,age from tb_emp")
  val rs: ResultSet = ps.executeQuery
  while (rs.next) {
    val name = rs.getString("name")
    val age = rs.getString("age")
    println(s"姓名是：$name，年龄是：$age")
  }

  //④资源释放
  if (rs != null) {
    rs.close()
  }
  if (ps != null) {
    ps.close()
  }
  if (conn != null) {
    conn.close()
  }
}
