package com.l000phone.spark_sql.day02.demo02_sparksession

import com.l000phone.spark_sql.day02.demo01_sql.SQLDemo
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

/**
  * Description：SparkSession实现三种创建方式演示<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月02日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SparkSessionCreateWayDemo {
  def main(args: Array[String]): Unit = {
    //方式1：Buildrer方式
    var spark: SparkSession = SparkSession.builder
      .appName(SQLDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    println(spark)

    println("\n______________________________________\n")

    //方式2：SparkConf方式
    val conf: SparkConf = new SparkConf
    conf.setAppName(SQLDemo.getClass.getSimpleName)
      .setMaster("local[*]")

    spark = SparkSession.builder
      .config(conf)
      .getOrCreate

    println(spark)


    println("\n______________________________________\n")

    //方式3：enableHiveSupport方式
    spark = SparkSession.builder
      .appName(SQLDemo.getClass.getSimpleName)
      .master("local[*]")
      .enableHiveSupport
      .getOrCreate

    println(spark)

  }
}
