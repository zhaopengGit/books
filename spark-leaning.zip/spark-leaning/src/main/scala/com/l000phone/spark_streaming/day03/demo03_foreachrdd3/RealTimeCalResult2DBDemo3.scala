package com.l000phone.spark_streaming.day03.demo03_foreachrdd3

import java.util

import com.l000phone.dao.IWordDao
import com.l000phone.dao.impl.WordDaoImpl
import com.l000phone.entity.Word
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{HashPartitioner, SparkContext}

/**
  * Description：需求：用Spark Streaming实现按批次累加功能,将实时计算后的结果落地到DB中, 使用批处理进行优化，使用优化后的sql (推荐)<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  *
  * @author 徐文波
  * @version : 1.0
  */
object RealTimeCalResult2DBDemo3 {


  def main(args: Array[String]): Unit = {
    //步骤：
    //前提：
    val spark: SparkSession = SparkSession
      .builder
      .appName(RealTimeCalResult2DBDemo3.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //①StreamingContext实例
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(2))

    //开启Chckpoint
    ssc.checkpoint("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\spark-streaming\\ck")

    //②DStream
    val ds: DStream[String] = ssc.socketTextStream("NODE03", 7777, StorageLevel.MEMORY_ONLY);


    //③迭代计算

    val middleDS: DStream[(String, Int)] = ds.flatMap(_.split("\\s+"))
      .map((_, 1))

    val dsResult: DStream[(String, Int)] = hasNameWay(middleDS, sc)


    //④处理结果
    dsResult.print

    //保存到db中
    save2DB(dsResult)

    //⑤启动
    ssc.start

    //⑥等待结束
    ssc.awaitTermination
  }


  /**
    * 有名函数
    *
    * @param middleDS
    * @return
    */
  def hasNameWay(middleDS: DStream[(String, Int)], sc: SparkContext): DStream[(String, Int)] = {

    val fun = (itr: Iterator[(String, Seq[Int], Option[Int])]) => {
      itr.map(perEle => (perEle._1, perEle._2.sum + perEle._3.getOrElse(0)))
    }

    middleDS.updateStateByKey(fun, new HashPartitioner(sc.defaultParallelism), true)
  }


  /**
    * 将计算的结果实时落地到表中
    *
    * @param dsResult
    */
  def save2DB(dsResult: DStream[(String, Int)]) = {
    dsResult.foreachRDD(rdd => { //将DStream中的每个元素与RDD中每个类型相同
      if (!rdd.isEmpty) {
        rdd.foreachPartition(itr => {
          if (!itr.isEmpty) {
            //分析迭代器
            analysisItrator(itr)
          }
        })

      }
    })
  }


  /**
    * 分析迭代器
    *
    * @param itr
    */
  def analysisItrator(itr: Iterator[(String, Int)]) = {
    //c)构建dao层的实例
    val dao: IWordDao = new WordDaoImpl

    //d)准备容器
    val container: java.util.List[Word] = new util.LinkedList[Word]
    itr.foreach(perEle => {
      val word = perEle._1
      val cnt = perEle._2

      //将当前的单词的结果封装到Word实例中，并存入容器
      container.add(new Word(word, cnt))
    })

    //批处理
    dao.batchOperate2(container)
  }

}
