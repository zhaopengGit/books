package com.l000phone.spark_streaming.day02.demo03_dynamicparam

import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * Description：需求：用Spark Streaming实现单词的实时计数,动态传入参数<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月05日
  *
  * @author 徐文波
  * @version : 1.0
  */
object DynamicParamDemo {
  def main(args: Array[String]): Unit = {
    //步骤：
    //拦截非法的参数
    if (args == null || args.length != 3) {
      println("请传入参数！durationTime,HostName,PortNumber")
      System.exit(1)
    }

//    val durationTime = args(0).trim.toLong
//    val hostName = args(1).trim
//    val portNum = args(2).trim.toInt

    val Array(durationTime,hostName,portNum)=args


    //前提：
    val spark: SparkSession = SparkSession
      .builder
      .appName(DynamicParamDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //①StreamingContext实例
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(durationTime.toLong))

    //②DStream
    val ds: DStream[String] = ssc.socketTextStream(hostName, portNum.toInt, StorageLevel.MEMORY_ONLY);


    //③迭代计算
    val dsResult: DStream[(String, Int)] = ds.flatMap(_.split("\\s+"))
      .map((_, 1))
      .reduceByKey(_ + _)


    //④显示结果
    dsResult.print(100)

    //⑤启动
    ssc.start

    //⑥等待结束
    ssc.awaitTermination
  }
}
