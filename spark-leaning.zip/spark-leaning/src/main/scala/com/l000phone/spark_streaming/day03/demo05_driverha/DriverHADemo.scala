package com.l000phone.spark_streaming.day03.demo05_driverha

import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * Description： Spark Streaming应用，在部署环节，一定要实现Driver进程的HA<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月09日
  *
  * @author 徐文波
  * @version : 1.0
  */
object DriverHADemo {
  def main(args: Array[String]): Unit = {
    //步骤：
    //前提：
    val spark: SparkSession = SparkSession
      .builder
      .appName(DriverHADemo.getClass.getSimpleName)
      //  .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    val ck: String = "hdfs://ns1/spark-streaming/ha/ck"

    //①StreamingContext实例
    val ssc: StreamingContext = StreamingContext.getOrCreate(ck, () => {
      val tmpSSC = new StreamingContext(sc, Seconds(2))

      //设置检查点,若是不设置，内部有一个默认的检查点的位置。
      tmpSSC.checkpoint(ck)

      //②DStream
      val ds: DStream[String] = tmpSSC.socketTextStream("node01", 7777, StorageLevel.MEMORY_ONLY);


      //③迭代计算
      val dsResult: DStream[(String, Int)] = ds.flatMap(_.split("\\s+"))
        .map((_, 1))
        .reduceByKey(_ + _)


      //④显示结果
      dsResult.print(100)


      //⑤返回StreamingContext的实例
      tmpSSC
    })


    //⑤启动（Driver ha之后，Driver重启，当前的application也会随之重启）
    ssc.start

    //⑥等待结束
    ssc.awaitTermination
  }


}
