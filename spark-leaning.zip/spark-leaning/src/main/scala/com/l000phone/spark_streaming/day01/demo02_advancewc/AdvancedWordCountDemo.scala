package com.l000phone.spark_streaming.day01.demo02_advancewc

import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{HashPartitioner, SparkContext}

/**
  * Description：需求：用Spark Streaming实现按批次累加功能<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月05日
  *
  * @author 徐文波
  * @version : 1.0
  */
object AdvancedWordCountDemo {


  def main(args: Array[String]): Unit = {
    //步骤：
    //前提：
    val spark: SparkSession = SparkSession
      .builder
      .appName(AdvancedWordCountDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //①StreamingContext实例
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(2))

    //开启Chckpoint
    ssc.checkpoint("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\spark-streaming\\ck")

    //②DStream
    val ds: DStream[String] = ssc.socketTextStream("node01", 7777, StorageLevel.MEMORY_ONLY);


    //③迭代计算

    val middleDS: DStream[(String, Int)] = ds.flatMap(_.split("\\s+"))
      .map((_, 1))

    //方式1：匿名函数
    //val dsResult: DStream[(String, Int)] = anonymousWay(middleDS)

    //方式2：有名函数
    val dsResult: DStream[(String, Int)] = hasNameWay(middleDS, sc)


    //④显示结果
    dsResult.print(100)

    //⑤启动
    ssc.start

    //⑥等待结束
    ssc.awaitTermination
  }


  /**
    * 有名函数
    *
    * @param middleDS
    * @return
    */
  def hasNameWay(middleDS: DStream[(String, Int)], sc: SparkContext): DStream[(String, Int)] = {

    val fun = (itr: Iterator[(String, Seq[Int], Option[Int])]) => {
      itr.map(perEle => (perEle._1, perEle._2.sum + perEle._3.getOrElse(0)))
    }

    middleDS.updateStateByKey(fun, new HashPartitioner(sc.defaultParallelism), true)
  }

  /**
    * 匿名函数方式
    *
    * @param middleDS
    * @return
    */
  def anonymousWay(middleDS: DStream[(String, Int)]) = {
    // 根据key，此处是单词进行操作的，有几个key，该方法的参数就会执行几次
    //每执行一次：
    //a)将当前这个单词的次数置于第一个参数中，形如：[1,1,1]
    //are you ok
    //are you ok  此时，第一参数中的值形如：[1,1]
    //b）第二个参数中存储的是当前这个key迄今为止出现的总次数，如：Option[3]
    //c)参数指定的函数体执行完毕后，返回的是：当前这个单词迄今为止出现的总次数：Option[5]

    val dsResult: DStream[(String, Int)] = middleDS.updateStateByKey((nowBatch: Seq[Int], histotyBatchSum: Option[Int]) => {
      val nowBatchSum = nowBatch.sum
      val newestSum = nowBatchSum + histotyBatchSum.getOrElse(0)
      Some(newestSum)
    })

    dsResult
  }
}
