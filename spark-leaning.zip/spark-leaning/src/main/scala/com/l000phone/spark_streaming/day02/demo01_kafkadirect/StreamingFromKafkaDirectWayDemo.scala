package com.l000phone.spark_streaming.day02.demo01_kafkadirect

import kafka.serializer.StringDecoder
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * Description：需求：Spark Streaming实时从Kafka采用direct方式拉取消息记性实时地计算<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月08日
  *
  * @author 徐文波
  * @version : 1.0
  */
object StreamingFromKafkaDirectWayDemo {
  def main(args: Array[String]): Unit = {
    //步骤：
    //前提：SparkSession,SparkContext
    val spark: SparkSession = SparkSession
      .builder
      .appName(StreamingFromKafkaDirectWayDemo.getClass.getSimpleName)
      //.master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //①StreamingContext
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(2))


    //设置checkpoint
    ssc.checkpoint(args(0).trim)


    //②从Kafka MessageQueue中拉取消息，封装到DStream中

    val originalDS: DStream[(String, String)] = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
      ssc,
      Map("metadata.broker.list" -> "NODE01:9092,NODE02:9092,NODE03:9092"),
      Set("hive")
    );


    //③迭代计算，并实时显示结果
    originalDS.map(_._2)
      .flatMap(_.split("\\s+"))
      .map((_, 1))
      .updateStateByKey((nowBatch: Seq[Int], historyResult: Option[Int]) => Some(nowBatch.sum + historyResult.getOrElse(0)))
      .print(1000)

    //④启动
    ssc.start

    //⑤等待结束
    ssc.awaitTermination

  }
}
