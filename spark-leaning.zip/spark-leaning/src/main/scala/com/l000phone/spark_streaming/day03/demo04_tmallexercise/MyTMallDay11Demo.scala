package com.l000phone.spark_streaming.day03.demo04_tmallexercise

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * Description：实时求出天猫双11那天不同商家同类型商品最受欢迎的top3的信息<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月09日
  *
  * @author 徐文波
  * @version : 1.0
  */
object MyTMallDay11Demo {
  def main(args: Array[String]): Unit = {
    //步骤：
    //前提：
    val spark: SparkSession = SparkSession
      .builder
      .appName(MyTMallDay11Demo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //①StreamingContext实例
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(2))

    //开启Chckpoint
    ssc.checkpoint("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\spark-streaming\\ck")

    //②DStream
    val ds: DStream[String] = ssc.socketTextStream("NODE03", 7777);


    //③迭代计算
    //a)实时求出不同商家同类型商品下单总量
    val middleDS: DStream[((String, String), Int)] = ds.map(perLine => {
      val arr = perLine.split("\\s+")
      val brand = arr(1).trim
      val goods = arr(2).trim
      ((brand, goods), 1)
    }).updateStateByKey((nowBatch: Seq[Int], historyResult: Option[Int]) => Some(nowBatch.sum + historyResult.getOrElse(0)))


    //b)分析中间的结果（DStream）,将其映射为一张表，使用sql求topN
    import spark.implicits._

    middleDS.foreachRDD(tmpRDD => {
      if (!tmpRDD.isEmpty()) {
        tmpRDD.map(perEle => Goods(perEle._1._1, perEle._1._2, perEle._2))
          .toDF
          .createOrReplaceTempView("tb_goods")

        //分析虚拟表，分组求top3
        spark.sql(
          """
            |select
            | *,
            | row_number() over (partition by goods order by cnt desc) level
            |from tb_goods
            |having level <= 3
          """.stripMargin).show(1000)
      }
    })

    //c）显示结果
    // finalDS.print(10000)

    //⑤启动
    ssc.start

    //⑥等待结束
    ssc.awaitTermination
  }


  /**
    * 商品样例类
    *
    * @param brand
    * @param goods
    * @param cnt
    */
  case class Goods(brand: String, goods: String, cnt: Int)

}
