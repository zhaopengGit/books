package com.l000phone.spark_streaming.day03.demo01_foreachrdd

import java.sql.{Connection, DriverManager, PreparedStatement, ResultSet}

import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{HashPartitioner, SparkContext}

/**
  * Description：需求：用Spark Streaming实现按批次累加功能,将实时计算后的结果落地到DB中<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  *
  * @author 徐文波
  * @version : 1.0
  */
object RealTimeCalResult2DBDemo {


  def main(args: Array[String]): Unit = {
    //步骤：
    //前提：
    val spark: SparkSession = SparkSession
      .builder
      .appName(RealTimeCalResult2DBDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //①StreamingContext实例
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(2))

    //开启Chckpoint
    ssc.checkpoint("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\spark-streaming\\ck")

    //②DStream
    val ds: DStream[String] = ssc.socketTextStream("NODE03", 7777, StorageLevel.MEMORY_ONLY);


    //③迭代计算

    val middleDS: DStream[(String, Int)] = ds.flatMap(_.split("\\s+"))
      .map((_, 1))

    val dsResult: DStream[(String, Int)] = hasNameWay(middleDS, sc)


    //④处理结果
    // a)显示结果
    dsResult.print(100)

    //b)保存到db中
    save2DB(dsResult)

    //⑤启动
    ssc.start

    //⑥等待结束
    ssc.awaitTermination
  }


  /**
    * 有名函数
    *
    * @param middleDS
    * @return
    */
  def hasNameWay(middleDS: DStream[(String, Int)], sc: SparkContext): DStream[(String, Int)] = {

    val fun = (itr: Iterator[(String, Seq[Int], Option[Int])]) => {
      itr.map(perEle => (perEle._1, perEle._2.sum + perEle._3.getOrElse(0)))
    }

    middleDS.updateStateByKey(fun, new HashPartitioner(sc.defaultParallelism), true)
  }


  /**
    * 将计算的结果实时落地到表中
    *
    * @param dsResult
    */
  def save2DB(dsResult: DStream[(String, Int)]) = {
    dsResult.foreachRDD(rdd => { //将DStream中的每个元素与RDD中每个类型相同
      if (!rdd.isEmpty) {
        rdd.foreachPartition(itr => {
          if (!itr.isEmpty) {
            //分析迭代器
            analysisItrator(itr)
          }
        })

      }
    })
  }


  /**
    * 分析迭代器
    *
    * @param itr
    */
  def analysisItrator(itr: Iterator[(String, Int)]) = {
    //JDBC经典的步骤
    //a)加载驱动
    classOf[com.mysql.jdbc.Driver]

    //b)构建Collection的实例
    val conn = DriverManager.getConnection("jdbc:mysql://NODE03:3306/dy?useUnicode=true&characterEncoding=utf-8", "root", "88888888")

    var rs: ResultSet = null
    var ps: PreparedStatement = null


    itr.foreach(perEle => {
      val word = perEle._1
      val cnt = perEle._2

      //判断：记录存在就更新，否则插入
      ps = conn.prepareStatement("select id from tb_word where word=?")
      //替换占位符的值
      ps.setString(1, word)
      rs = ps.executeQuery()
      val isExists = rs.next()
      if (isExists) { //更新
        ps = conn.prepareStatement("update tb_word set cnt=? where word=?")
      } else { //插入
        ps = conn.prepareStatement("insert into tb_word(id,cnt,word) values(null,?,?)")
      }
      ps.setInt(1, cnt)
      ps.setString(2, word)

      ps.executeUpdate

    })

    //资源释放
    releaseResource(rs, ps, conn)
  }

  /**
    * 释放资源
    *
    * @param rs
    * @param ps
    * @param conn
    * @return
    */
  def releaseResource(rs: ResultSet, ps: PreparedStatement, conn: Connection) = {
    if (rs != null) {
      rs.close()
    }
    if (ps != null) {
      ps.close()
    }
    if (conn != null) {
      conn.close()
    }
  }
}
