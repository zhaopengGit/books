package com.l000phone.spark_streaming.day02.demo05_blacklist

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * Description：需求：用Spark Streaming实现单词的实时计数,动态传入参数<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月05日
  *
  * @author 徐文波
  * @version : 1.0
  */
object FilterBlackListDemo {
  def main(args: Array[String]): Unit = {
    //步骤：

    //前提：
    val spark: SparkSession = SparkSession
      .builder
      .appName(FilterBlackListDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //①StreamingContext实例
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(2.toLong))

    //②DStream
    val ds: DStream[String] = ssc.socketTextStream("NODE01", 6666);


    //③计算

    //a) 黑名单
    val blackRDD: RDD[(String, String)] = sc.parallelize(Seq(("110.52.250.126", ""), ("27.19.74.143", "")))

    //b)分析
    val dsResult:DStream[String] = ds.transform(rdd => {
      //i)变形成对偶元组，形如：（"110.52.250.127","8.35.201.160##2017-05-30 17:38:21##GET /uc_server/data/avatar/000/04/12/85_avatar_middle.jpg HTTP/1.1##200##3174"）
      val tupleRDD:RDD[(String,String)] = rdd.map(perLine => {
        val ip = perLine.split("##")(0)
        (ip, perLine)
      })

      //ii)左外连接查询
      val joinRDD: RDD[(String, (String, Option[String]))] = tupleRDD.leftOuterJoin(blackRDD)

      ///iii)筛选,并变形
     val whiteRDD:RDD[String] =  joinRDD.filter(_._2._2==None)
          .map(_._2._1)


      ///iiii)返回
      whiteRDD
    })


    //④显示结果
    dsResult.print(100)


    //⑤启动
    ssc.start

    //⑥等待结束
    ssc.awaitTermination
  }
}
