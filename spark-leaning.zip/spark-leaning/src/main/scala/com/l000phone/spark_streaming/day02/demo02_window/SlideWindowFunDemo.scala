package com.l000phone.spark_streaming.day02.demo02_window

import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * Description：需求：用Spark Streaming结合滑动窗口函数实现单词的实时计数<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  *
  * @author 徐文波
  * @version : 1.0
  */
object SlideWindowFunDemo {
  def main(args: Array[String]): Unit = {
    //步骤：
    //前提：
    val spark: SparkSession = SparkSession
      .builder
      .appName(SlideWindowFunDemo.getClass.getSimpleName)
      .master("local[*]")
      .getOrCreate

    val sc: SparkContext = spark.sparkContext

    //①StreamingContext实例
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(2))

    //②DStream
    val ds: DStream[String] = ssc.socketTextStream("node01", 7777, StorageLevel.MEMORY_ONLY);


    //③迭代计算
    val dsResult: DStream[(String, Int)] = ds.flatMap(_.split("\\s+"))
      .map((_, 1))
      .reduceByKeyAndWindow((x:Int,y:Int)=>x+y,Seconds(4),Seconds(2))


    //④显示结果
    dsResult.print(100)

    //⑤启动
    ssc.start

    //⑥等待结束
    ssc.awaitTermination
  }
}
