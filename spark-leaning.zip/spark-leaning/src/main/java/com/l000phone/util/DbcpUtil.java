package com.l000phone.util;

import org.apache.commons.dbcp.BasicDataSourceFactory;

import javax.sql.DataSource;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Description：xxx<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date：2020年01月23日
 *
 * @author 徐文波
 * @version : 1.0
 */
public class DbcpUtil {
    private static DataSource ds;

    static {
        try {
            InputStream in = DbcpUtil.class.getClassLoader().getResourceAsStream("src/main/tmp/dbcp.properties");
            Properties props = new Properties();
            props.load(in);
            ds = BasicDataSourceFactory.createDataSource(props);
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    public static DataSource getDataSouce() {
        return ds;
    }

    /**
     * 从连接池获得连接的实例
     *
     * @return
     */
    public static Connection getConnection() {
        try {
            return ds.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
