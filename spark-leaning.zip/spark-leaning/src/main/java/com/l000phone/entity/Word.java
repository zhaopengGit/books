package com.l000phone.entity;

import java.io.Serializable;

/**
 * Description：Word实体类<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date： 2020年01月09日
 *
 * @author 徐文波
 * @version : 1.0
 */
public class Word implements Serializable {
    /**
     * 编号
     */
    private int id;
    /**
     * 单词
     */
    private String word;
    /**
     * 次数
     */
    private int cnt;

    public Word() {
    }

    public Word(String word, int cnt) {
        this.word = word;
        this.cnt = cnt;
    }

    public Word(int id, String word, int cnt) {
        this.id = id;
        this.word = word;
        this.cnt = cnt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }
}
