package com.l000phone.entity;

import java.io.Serializable;

/**
 * Description：员工实体类<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date： 2020年01月02日
 *
 * @author 徐文波
 * @version : 1.0
 */
public class Emp  implements Serializable {
    private int id;
    private String name;
    private String address;
    private double salary;

    public Emp() {
    }

    public Emp(int id, String name, String address, double salary) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.salary = salary;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
