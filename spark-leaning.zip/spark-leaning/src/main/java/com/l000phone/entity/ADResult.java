package com.l000phone.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Description：广告每小时点击数前3名的结果实体类<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date： 2020年01月27日
 *
 * @author 徐文波
 * @version : 1.0
 */
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
public class ADResult {
    private String province;
    private int hour;
    private int adId;
    private int cnt;


    public ADResult() {
    }

    public ADResult(String province, int hour, int adId, int cnt) {
        this.province = province;
        this.hour = hour;
        this.adId = adId;
        this.cnt = cnt;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getAdId() {
        return adId;
    }

    public void setAdId(int adId) {
        this.adId = adId;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }
}
