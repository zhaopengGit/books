package com.l000phone.dao;

import com.l000phone.entity.Word;

import java.util.List;

/**
 * Description：单词操作的数据访问层接口<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date： 2020年01月09日
 *
 * @author 徐文波
 * @version : 1.0
 */
public interface IWordDao {

    /**
     * 批量操作
     *
     * @param words
     */
    void batchOperate(List<Word> words);

    /**
     * 批量操作
     *
     * @param words
     */
    void batchOperate2(List<Word> words);
}
