package com.l000phone.dao;

import com.l000phone.entity.ADResult;

/**
 * Description：广告管理模块数据访问层接口<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date： 2020年01月27日
 *
 * @author 徐文波
 * @version : 1.0
 */
public interface IADDao {
    /**
     * 保存
     *
     * @param entity
     */
    void insert(ADResult entity);
}
