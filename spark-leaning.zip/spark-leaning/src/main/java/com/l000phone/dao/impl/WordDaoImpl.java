package com.l000phone.dao.impl;

import com.l000phone.dao.IWordDao;
import com.l000phone.entity.Word;
import com.l000phone.util.DbcpUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 * Description：单词操作的数据访问层接口实现类<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date： 2020年01月09日
 *
 * @author 徐文波
 * @version : 1.0
 */
public class WordDaoImpl implements IWordDao {

    private QueryRunner qr = new QueryRunner(DbcpUtil.getDataSouce());


    /**
     * @param words 包含了两部分数据，DB中已经存在了单词，DB不存在
     */
    @Override
    public void batchOperate(List<Word> words) {
        try {
            //步骤：
            //①将容器拆解从两个容器（updateContainer, insertContainer）
            List<Word> updateContainer = new LinkedList<>();
            List<Word> insertContainer = new LinkedList<>();
            for (Word word : words) {
                Word instance = qr.query("select id from tb_word where word=?", new BeanHandler<>(Word.class), word.getWord());
                if (instance == null) {
                    insertContainer.add(word);
                } else {
                    updateContainer.add(word);
                }
            }

            //②批量插入
            if (insertContainer.size() > 0) {
                commonBatchDealWith(insertContainer, "insert into tb_word(cnt,word) values (?,?)");
            }


            //③批量更新
            if (updateContainer.size() > 0) {
                commonBatchDealWith(updateContainer, "update tb_word set cnt=? where word=?");
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /**
     * 共通的批处理
     *
     * @param container
     * @param sql
     */
    private void commonBatchDealWith(List<Word> container, String sql) throws SQLException {
        Object[][] params = new Object[container.size()][];
        for (int i = 0; i < params.length; i++) {
            Word word = container.get(i);
            params[i] = new Object[]{word.getCnt(), word.getWord()};
        }
        qr.batch(sql, params);
    }


    /**
     * 使用优化后的sql
     *
     * @param words
     */
    @Override
    public void batchOperate2(List<Word> words) {
        try {
            //步骤：
            //sql
            String sql = "insert into tb_word(word,cnt) values(?,?) on duplicate key update cnt=?";

            //准备参数，并填充
            Object[][] params = new Object[words.size()][];

            for (int i = 0; i < params.length; i++) {
                Word word = words.get(i);
                params[i] = new Object[]{word.getWord(),word.getCnt(),word.getCnt()};
            }

            //送给远程的db server批量执行
            qr.batch(sql,params);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
