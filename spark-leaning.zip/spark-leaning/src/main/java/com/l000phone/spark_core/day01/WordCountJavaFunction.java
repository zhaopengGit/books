package com.l000phone.spark_core.day01;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

import java.util.Arrays;

/**
 * Description：Scala版本入门级的案例之WordCount<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date： 2020年01月24日
 *
 * @author 徐文波
 * @version : 1.0
 */
public class WordCountJavaFunction {
    public static void main(String[] args) {
        //步骤：
        //前提:
        //拦截非法的参数
        if (args == null || args.length != 2) {
            System.out.println("请录入参数！参数1→ inputPath, 参数2→outputPath");
            System.exit(1);
        }

        String inputPath = args[0].trim();
        String outputPath = args[1].trim();


        //①构建SparkConf的实例
        //通过参数传递进来
        SparkConf conf = new SparkConf();
        conf.setAppName(WordCountJavaFunction.class.getSimpleName());
        conf.setMaster("local[*]");

        //②构建SparkContext的实例 （SparkSession的实例）
        JavaSparkContext jsc = new JavaSparkContext(conf);


        //③分步骤求WordCount
        //a)加载指定的文件为RDD (RDD:弹性分布式数据集，可以理解为集合，该集合中存储的元素跨越了多个虚拟机的内存，就是worker守护进行启动着的Executor进程对应的内存区域中)
        JavaRDD<String> lineRDD = jsc.textFile(inputPath);

        //b) 将文件中每行内容转换成数组并压平，置于一个全新的RDD中
//        JavaRDD<String> wordRDD = lineRDD.flatMap(new FlatMapFunction<String, String>() {
//
//            @Override
//            public Iterator<String> call(String line) throws Exception {
//                String[] arr = line.split("\\s+");
//                return Arrays.asList(arr).iterator();
//            }
//        });

        JavaRDD<String> wordRDD = lineRDD.flatMap(line->Arrays.asList(line.split("\\s+")).iterator());

        //c)将RDD中每个元素转换成元组
//        JavaPairRDD<String, Integer> tupleRDD = wordRDD.filter(new Function<String, Boolean>() {
//            @Override
//            public Boolean call(String v1) throws Exception {
//                return !"".equals(v1.trim());
//            }
//        }) .mapToPair(new PairFunction<String, String, Integer>() {
//            @Override
//            public Tuple2<String, Integer> call(String word) throws Exception {
//                return new Tuple2(word, 1);
//            }
//        });

        JavaPairRDD<String, Integer> tupleRDD =wordRDD.filter(v->!"".equals(v.trim()))
                .mapToPair(word->new Tuple2(word, 1));


        //d)计算单词出现的次数
//        JavaPairRDD<String, Integer> sumRDD = tupleRDD.reduceByKey(new Function2<Integer, Integer, Integer>() {
//            @Override
//            public Integer call(Integer v1, Integer v2) throws Exception {
//                return v1 + v2;
//            }
//        });

        JavaPairRDD<String, Integer> sumRDD =tupleRDD.reduceByKey((v1,v2)->v1+v2);

        //e)处理结果（i→排序，打印输出；ii→排序，存储起来）

//        JavaPairRDD<Integer, String> swapRDD = sumRDD.mapToPair(new PairFunction<Tuple2<String, Integer>, Integer, String>() {
//            @Override
//            public Tuple2<Integer, String> call(Tuple2<String, Integer> tuple) throws Exception {
//                return tuple.swap();
//            }
//        });

        JavaPairRDD<Integer, String> swapRDD =sumRDD.mapToPair(tuple->tuple.swap());


//        JavaPairRDD<String, Integer> swapAndSordRDD = swapRDD.sortByKey(false, 1).mapToPair(new PairFunction<Tuple2<Integer, String>, String, Integer>() {
//
//            @Override
//            public Tuple2<String, Integer> call(Tuple2<Integer, String> tuple) throws Exception {
//                return tuple.swap();
//            }
//        });
//
//
//        swapAndSordRDD.foreach(new VoidFunction<Tuple2<String, Integer>>() {
//            @Override
//            public void call(Tuple2<String, Integer> tuple) throws Exception {
//                System.out.println(tuple);
//            }
//        });
//
//        swapAndSordRDD.saveAsTextFile(outputPath);


        swapRDD.sortByKey(false, 1).mapToPair(tuple->tuple.swap()).saveAsTextFile(outputPath);


        //④资源释放
        jsc.stop();
    }
}
