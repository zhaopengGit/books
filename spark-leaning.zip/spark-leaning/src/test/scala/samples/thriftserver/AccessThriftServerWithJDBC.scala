package samples.thriftserver

import java.sql.{DriverManager, ResultSet}

import org.apache.hive.jdbc.HiveDriver


/**
  * Description：使用JDBC技术去访问ThriftServer<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  *
  * @author 徐文波
  * @version : 1.0
  */
object AccessThriftServerWithJDBC extends App {
  //步骤：
  //①加载驱动
  classOf[HiveDriver]

  //②获得连接
  val conn = DriverManager.getConnection("jdbc:hive2://NODE01:10001", "root", "123")

  //③准备PreparedStatement
  val ps = conn.prepareStatement("select * from tb_emp")

  //④执行sql
  val rs: ResultSet = ps.executeQuery

  //⑤处理结果
  while (rs.next) {
    println(s"编号：${rs.getInt("id")},姓名：${rs.getString("name")}，生日：${rs.getString("birthday")}")
  }

  //⑥释放资源
   if(rs!=null){
     rs.close()
   }
  if(ps!=null){
    ps.close()
  }
  if(conn!=null){
    conn.close()
  }
}
