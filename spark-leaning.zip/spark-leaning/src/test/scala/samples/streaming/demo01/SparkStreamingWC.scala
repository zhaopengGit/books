package samples.streaming.demo01

import org.apache.spark.streaming.dstream.{DStream, ReceiverInputDStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Description：xxxx<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月05日
  *
  * @author 徐文波
  * @version : 1.0
  */
object SparkStreamingWC {
  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setAppName("SparkStreamingWC").setMaster("local[2]")
    val sc = new SparkContext(conf)
    // 创建SparkStreaming的上下文对象
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(5))

    // 从NetCat服务里获取数据
    val dStream: ReceiverInputDStream[String] = ssc.socketTextStream("node01", 8888)

    // 调用DStream里的api进行计算
    val res: DStream[(String, Int)] = dStream.flatMap(_.split(" ")).map((_, 1)).reduceByKey(_+_)

    res.print()

    // 提交任务到集群
    ssc.start()

    // 线程等待，等待处理任务
    ssc.awaitTermination()

  }
}
