package samples.streaming.demo02

import org.apache.spark.{HashPartitioner, SparkConf}
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Milliseconds, StreamingContext}

/**
  * 实现按批次累加功能，需要调用updateStateByKey
  * 其中需要自定义一个函数，该函数是对历史结果数据和当前批次数据的操作过程
  * 该函数中第一个参数代表每个单词
  * 第二个参数代表当前批次单词出现的次数：Seq(1,1,1,1)
  * 第三个参数代表之前批次累加的结果，可能有值，也可能没有值，所以在获取的时候要用getOrElse方法
  */
object SparkStreamingACCWC {
  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setAppName("SparkStreamingACCWC").setMaster("local[2]")
    val ssc = new StreamingContext(conf, Milliseconds(5000))

    // 设置检查点目录
//    ssc.checkpoint("hdfs://node01:9000/cp-20200306-1")
    ssc.checkpoint("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\spark-streaming\\ck")

    // 获取数据
    val dStream = ssc.socketTextStream("node01", 8888)
    val tup: DStream[(String, Int)] = dStream.flatMap(_.split(" ")).map((_, 1))
    val res: DStream[(String, Int)] =
      tup.updateStateByKey(func, new HashPartitioner(ssc.sparkContext.defaultParallelism), true)

    res.print()
      
    ssc.start()
    ssc.awaitTermination()
  }

  val func = (it: Iterator[(String, Seq[Int], Option[Int])]) => {
    it.map(x => {
      (x._1, x._2.sum + x._3.getOrElse(0))
    })
  }
}