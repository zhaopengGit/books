package samples.streaming.demo04

import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}

object WindowOperationWC {
  def main(args: Array[String]): Unit = {
    //LoggerLevels.setStreamingLogLevels()

    val conf = new SparkConf().setAppName("WindowOperationWC").setMaster("local[2]")
    val ssc = new StreamingContext(conf, Seconds(5))

    ssc.checkpoint("c://cp-20200306-3")

    val dStream = ssc.socketTextStream("node01", 8888)

    val tup = dStream.flatMap(_.split(" ")).map((_, 1))

    // 调用窗口操作来计算数据的聚合。批次间隔是5秒，设置窗口长度是10，滑动间隔是10秒
    val res: DStream[(String, Int)] =
      tup.reduceByKeyAndWindow((x: Int, y: Int) => (x + y), Seconds(10), Seconds(10))

    res.print()

    ssc.start()
    ssc.awaitTermination()
  }
}