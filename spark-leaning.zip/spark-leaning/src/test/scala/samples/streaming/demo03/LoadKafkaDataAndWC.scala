package samples.streaming.demo03

import org.apache.spark.{HashPartitioner, SparkConf}
import org.apache.spark.streaming.dstream.{DStream, ReceiverInputDStream}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Seconds, StreamingContext}

object LoadKafkaDataAndWC {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("LoadKafkaDataAndWC").setMaster("local[2]")
    val ssc = new StreamingContext(conf, Seconds(5))

    // 设置请求kafka的几个参数
    val Array(zkQuorum, group, topics, numTheads) = args

    // 设置检查点
    ssc.checkpoint("c://cp-20200306-2")

    // 获取每一个topic并放到一个Map里
    val topicMap: Map[String, Int] = topics.split(",").map((_, numTheads.toInt)).toMap

    // 调用KafkaUtils工具类获取kafka的数据
    val data: ReceiverInputDStream[(String, String)] =
      KafkaUtils.createStream(ssc, zkQuorum, group, topicMap)

    // 因为DStream里的key是offset值，把DStream里的value数据取出来
    val lines: DStream[String] = data.map(_._2)
    val tup = lines.flatMap(_.split(" ")).map((_, 1))
    val res: DStream[(String, Int)] = tup.updateStateByKey(func, new HashPartitioner(ssc.sparkContext.defaultParallelism), true)

    res.print()

    ssc.start()
    ssc.awaitTermination()
  }

  val func = (it: Iterator[(String, Seq[Int], Option[Int])]) => {
    it.map{
      case (x, y, z) => {
        (x, y.sum + z.getOrElse(0))
      }
    }
  }
}