package samples.toint

/**
  * Description：xxxx<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月28日
  *
  * @author 徐文波
  * @version : 1.0
  */
object ToIntDo {
  def main(args: Array[String]): Unit = {
      //println("abc".toInt)
      println("123".toInt)
  }
}
