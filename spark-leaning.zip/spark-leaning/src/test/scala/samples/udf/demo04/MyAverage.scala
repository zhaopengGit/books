package samples.udf.demo04

import org.apache.spark.sql.SparkSession

//开窗窗函数
object MyAverage {
  case class Score(cls: String, score: Int)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("MyAverage").master("local[*]").getOrCreate()
    import spark.implicits._
    val rdd = spark.sparkContext.textFile("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\scores.txt")
    val df = rdd.map(line => {
      val arr = line.split("\\s+")
      Score(arr(0), arr(1).toInt)
    }).toDF

        df.createOrReplaceTempView("score")
//        df.show()

    //    println("/**************  求每个班最高成绩学生的信息（groupBY）  ***************/")
    //    //先写的 进行查询  这样可以进行班级分组并得到分数
//        spark.sql("select cls, max(score) max from score group by cls").show()

    //    //这句话在集合Sparkcore想一样
    //    /*这句话select class, max(score) max from score group by class
    //      相当于key是class  然后执行了group by  求了一个max(score) 得到一个RDD然后和原有RDD执行了一个Join
    //      直白一些(class相当于key,score相当于value) 然后执行groupbyKey  --> 生成了(class,max) 这个RDD
    //      然后将(class,max)转了一下 --> (class_max,1)后面的数无所谓
    //      然就相当于将数据中也做了一个(class_max,score)  -->和之前的RDD -->进行join --> 在进行map
    //    */
    //    spark.sql("select a.name, b.class, b.max from score a, " +
    //      "(select class, max(score) max from score group by class) as b " +
    //      "where a.score = b.max").show()

    //      //添加一个函数可以对表中动态添加一列即 以对表中的分数添加排序
    //      //这里的over就是开窗函数 , row_number是分析函数(排名函数)
//        spark.sql("select cls,score,row_number() over(partition by cls order by score desc) rank from score ").show()



    //        println("    /*******  计算结果的表  *******")
//        spark.sql("select * from " +
//          "( select  cls,score,rank() over(partition by cls order by score desc) rank from score) " +
//          "as t " +
//          "where t.rank<=3").show()

    //    println("//***************  求每个班最高成绩学生的信息  ***************/")
    //    println("    /*******  开窗函数的表  ********/")
    //    spark.sql("select name,class,score, rank() over(partition by class order by score desc) rank from score").show()
    //
    //    println("    /*******  计算结果的表  *******")
    //    spark.sql("select * from " +
    //      "( select name,class,score,rank() over(partition by class order by score desc) rank from score) " +
    //      "as t " +
    //      "where t.rank=1").show()
  }

}