package samples.udf.demo03

import org.apache.spark.sql.{Encoder, Encoders, SparkSession}
import org.apache.spark.sql.expressions.Aggregator
import samples.udf.demo02.MyAverage.spark

/**
  * Description：UDAF函数支持DataSet(强类型)<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月01日
  *
  * @author 徐文波
  * @version : 1.0
  */
case class MyAverage() extends Aggregator[Employee,Average,Double]{
  /**
    * 初始化方法 初始化每一个分区中的 共享变量即定义一个数据结构，保存工资总数和工资总个数，初始都为0
    *
    * @return
    */
  override def zero: Average = Average(0.0,0.0)

  /**
    * 每一个分区中的每一条数据聚合的时候需要调用该方法
    *
    * @param buffer
    * @param employee
    * @return
    */
  override def reduce(buffer: Average, employee: Employee): Average = {
    buffer.sum += employee.salary
    buffer.count += 1
    buffer
  }

  /**
    * 将每一个分区的输出 合并 形成最后的数据
    *
    * @param b1
    * @param b2
    * @return
    */
  override def merge(b1: Average, b2: Average): Average = {
    b1.sum += b2.sum
    b1.count += b2.count
    b1
  }

  /**
    * 给出计算结果
    *
    * @param reduction
    * @return
    */
  override def finish(reduction: Average): Double = reduction.sum/reduction.count

  /**
    * 设定之间值类型的编码器，要转换成case类
    *
    * Encoders.product是进行scala元组和case类转换的编码器
    * @return
    */
  override def bufferEncoder: Encoder[Average] = Encoders.product

  /**
    * 设定最终输出值的编码器
    *
    * @return
    */
  override def outputEncoder: Encoder[Double] = Encoders.scalaDouble
}



//自定义UDAF函数
// 既然是强类型，一般有case类
case class Employee(name: String, salary: Double)
case class Average(var sum: Double, var count: Double)


object MyAverage{
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("MyAverage").master("local[*]").getOrCreate()
    import spark.implicits._
    val ds = spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json").as[Employee]
    ds.show()
    val averageSalary = new MyAverage().toColumn.name("平均薪水")
    val result = ds.select(averageSalary)
    result.show()
  }

}