package samples.udf.demo02

import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types.{DataType, DoubleType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}

/**
  * Description：UDAF函数支持DataFrame,弱类型<br/>
  * Copyright (c) ， 2020， Jansonxu <br/>
  * This program is protected by copyright laws. <br/>
  * Date： 2020年01月01日
  *
  * @author 徐文波
  * @version : 1.0
  */
class MyAverage extends UserDefinedAggregateFunction {
  /**
    * 输入数据
    *
    * @return
    */
  override def inputSchema: StructType = StructType(List(StructField("Salary", DoubleType, true)))

  /**
    * 每一个分区中的 共享变量 存储记录的值
    *
    * @return
    */
  override def bufferSchema: StructType =
    StructType(StructField("sum", DoubleType) :: StructField("count", DoubleType) :: Nil)

  /**
    * 返回值的数据类型表示UDAF函数的输出类型
    *
    * @return
    */
  override def dataType: DataType = DoubleType

  /**
    * 如果有相同的输入,那么是否UDAF函数有相同的输出,有true 否则false
    * UDAF函数中如果输入的数据掺杂着时间,不同时间得到的结果可能是不一样的所以这个值可以设置为false
    * 若不掺杂时间,这个值可以输入为true
    *
    * @return
    */
  override def deterministic: Boolean = true

  /**
    * 初始化对Buffer中的属性初始化即初始化分区中每一个共享变量
    *
    * @param buffer
    */
  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    // 存工资的总额
    buffer(0) = 0.0 //取得就是sum
    // 存工资的个数
    buffer(1) = 0.0 //取得就是count
  }

  /**
    * 相同Execute间的数据合并,合并小聚合中的数据即每一个分区中的每一条数据聚合的时候需要调用的方法
    * 第一个参数buffer还是共享变量
    * 第二个参数是一行数据即读取到的数据是以一行来看待的
    */
  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    if (!input.isNullAt(0)) {
      //获取这一行中的工资,然后将工资添加到该方法中
      buffer(0) = buffer.getDouble(0) + input.getDouble(0)
      //将工资的个数进行加1操作最终是为了计算所有的工资的个数
      buffer(1) = buffer.getDouble(1) + 1
    }
  }

  /**
    * 不同Execute间的数据合并,合并大数据中的数即将每一个分区的输出合并形成最后的数据
    *
    * @param buffer1
    * @param buffer2
    */
  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    //合并总的工资
    buffer1(0) = buffer1.getDouble(0) + buffer2.getDouble(0)
    //合并总的工资个数
    buffer1(1) = buffer1.getDouble(1) + buffer2.getDouble(1)
  }

  /**
    * 计算最终结果
    *
    * @param buffer
    * @return
    */
  override def evaluate(buffer: Row): Any = buffer.getDouble(0) / buffer.getDouble(1)
}


object MyAverage extends App{
  val spark = SparkSession.builder().appName("MyAverage").master("local[*]").getOrCreate()
  // 注册函数
  spark.udf.register("myAverage",new MyAverage)

  val df = spark.read.json("file:///C:\\Users\\Administrator\\IdeaProjects\\spark-leaning\\data\\sql\\employees.json")
  df.createOrReplaceTempView("employees")
  df.show()
  //虽然没有使用groupby那么会将整个数据作为一个组
  val result = spark.sql("SELECT myAverage(salary) as average_salary FROM employees")
  result.show()
}
