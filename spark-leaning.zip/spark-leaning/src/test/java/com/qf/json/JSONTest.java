package com.qf.json;

import com.alibaba.fastjson.JSON;
import com.l000phone.entity.Student;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Description：xxxx<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date： 2020年01月28日
 *
 * @author 徐文波
 * @version : 1.0
 */
public class JSONTest {

    public static void main(String[] args) throws IOException {
        List<Student> stus = new LinkedList<>();
        Collections.addAll(stus, new Student(1, "杰克逊", "北京"), new Student(2, "Andy", "香港"), new Student(3, "marry", "香港"));

        PrintWriter writer = new PrintWriter(new File("data/json/stu.json"));
        for (Student stu : stus) {
            String jsonStr = JSON.toJSONString(stu);
            writer.println(jsonStr);
            writer.flush();
        }
        writer.close();
    }

}
