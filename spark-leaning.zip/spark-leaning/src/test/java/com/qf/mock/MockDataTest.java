package com.qf.mock;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;

/**
 * Description：xxxx<br/>
 * Copyright (c) ， 2020， Jansonxu <br/>
 * This program is protected by copyright laws. <br/>
 * Date： 2020年01月26日
 *
 * @author 徐文波
 * @version : 1.0
 */
public class MockDataTest {

    public static void main(String[] args) throws ParseException {
        //模拟数据
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        // 2020-01-10 10:40:50
        // 2020-01-10 09:40:50
        // 2020-01-10 15:40:50
        // 2020-01-10 14:40:50
        // 2020-01-10 22:40:50

        List<String> timeContainer = new LinkedList<>();
        timeContainer.add("2020-01-10 10:40:50");
        timeContainer.add("2020-01-10 09:40:50");
        timeContainer.add("2020-01-10 15:40:50");
        timeContainer.add("2020-01-10 14:40:50");
        timeContainer.add("2020-01-10 22:40:50");

        timeContainer.add("2020-01-10 01:40:50");
        timeContainer.add("2020-01-10 03:40:50");
        timeContainer.add("2020-01-10 04:40:50");
        timeContainer.add("2020-01-10 04:40:50");
        timeContainer.add("2020-01-10 15:40:50");


        for(String time:timeContainer){
            long timeLong = sdf.parse(time).getTime();
            System.out.println(timeLong);
        }

    }
}
